import Foundation

/// Rational numbers for predefined temperaments.
/// Equivalent to `TemperamentRationalNumbers.kt`.

let rationalNumberTemperamentWerckmeisterVI: [RationalNumber] = [
    RationalNumber(1, 1), // C
    RationalNumber(196, 186), // C#
    RationalNumber(196, 175), // D
    RationalNumber(196, 165), // Eb
    RationalNumber(196, 156), // E
    RationalNumber(196, 147), // F
    RationalNumber(196, 139), // F#
    RationalNumber(196, 131), // G
    RationalNumber(196, 124), // G#
    RationalNumber(196, 117), // A
    RationalNumber(196, 110), // Bb
    RationalNumber(196, 104), // B
    RationalNumber(2, 1), // C2
]

let rationalNumberTemperamentPure: [RationalNumber] = [
    RationalNumber(1, 1), // C
    RationalNumber(16, 15), // C#
    RationalNumber(9, 8), // D
    RationalNumber(6, 5), // Eb
    RationalNumber(5, 4), // E
    RationalNumber(4, 3), // F
    RationalNumber(45, 32), // F#
    RationalNumber(3, 2), // G
    RationalNumber(8, 5), // G#
    RationalNumber(5, 3), // A
    RationalNumber(9, 5), // Bb
    RationalNumber(15, 8), // B
    RationalNumber(2, 1), // C2
]
