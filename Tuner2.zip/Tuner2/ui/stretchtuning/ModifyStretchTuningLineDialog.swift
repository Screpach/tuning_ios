import SwiftUI

struct ModifyStretchTuningLineDialog: View {
    let initialUnstretchedFrequency: Double?
    let initialStretchInCents: Double?
    let key: Int // Used to identify the line being edited
    let onDismiss: () -> Void
    let onConfirm: (Int, Double, Double) -> Void

    @State private var unstretchedFrequencyString: String
    @State private var stretchInCentsString: String
    
    // Validation states
    @State private var isFrequencyValid: Bool = true
    @State private var isStretchValid: Bool = true
    
    init(
        initialUnstretchedFrequency: Double? = nil,
        initialStretchInCents: Double? = nil,
        key: Int,
        onDismiss: @escaping () -> Void,
        onConfirm: @escaping (Int, Double, Double) -> Void
    ) {
        self.initialUnstretchedFrequency = initialUnstretchedFrequency
        self.initialStretchInCents = initialStretchInCents
        self.key = key
        self.onDismiss = onDismiss
        self.onConfirm = onConfirm
        
        // Initialize State
        _unstretchedFrequencyString = State(initialValue: initialUnstretchedFrequency.map { String(format: "%.2f", $0) } ?? "")
        _stretchInCentsString = State(initialValue: initialStretchInCents.map { String(format: "%.2f", $0) } ?? "")
    }

    var body: some View {
        ZStack {
            Color.black.opacity(0.4).ignoresSafeArea()
                .onTapGesture { onDismiss() }
            
            VStack(spacing: 20) {
                Text(initialUnstretchedFrequency == nil ? "Add Value" : "Edit Value")
                    .font(.headline)
                    .padding(.top)
                
                VStack(spacing: 16) {
                    // Frequency Input
                    TextField("Frequency (Hz)", text: $unstretchedFrequencyString)
                        .keyboardType(.decimalPad)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(isFrequencyValid ? Color.secondary.opacity(0.5) : Color.red, lineWidth: 1)
                        )
                        .onChange(of: unstretchedFrequencyString) { newValue in
                            validateFrequency(newValue)
                        }
                    
                    if !isFrequencyValid {
                        Text("Value must be a number > 0")
                            .font(.caption)
                            .foregroundColor(.red)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    // Stretch Input
                    TextField("Stretch (cents)", text: $stretchInCentsString)
                        .keyboardType(.decimalPad)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(isStretchValid ? Color.secondary.opacity(0.5) : Color.red, lineWidth: 1)
                        )
                        .onChange(of: stretchInCentsString) { newValue in
                            validateStretch(newValue)
                        }
                    
                    if !isStretchValid {
                        Text("Value must be a valid number")
                            .font(.caption)
                            .foregroundColor(.red)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(.horizontal)

                HStack {
                    Button("Cancel") {
                        onDismiss()
                    }
                    .foregroundColor(.red)
                    
                    Spacer()
                    
                    Button("OK") {
                        if let freq = Double(unstretchedFrequencyString),
                           let stretch = Double(stretchInCentsString),
                           freq > 0 {
                            onConfirm(key, freq, stretch)
                        }
                    }
                    .disabled(!isFrequencyValid || !isStretchValid || unstretchedFrequencyString.isEmpty || stretchInCentsString.isEmpty)
                }
                .padding()
            }
            .background(Color(UIColor.systemBackground))
            .cornerRadius(16)
            .padding(32)
            .shadow(radius: 10)
        }
    }
    
    private func validateFrequency(_ value: String) {
        if let d = Double(value), d > 0 {
            isFrequencyValid = true
        } else {
            isFrequencyValid = false
        }
    }
    
    private func validateStretch(_ value: String) {
        if Double(value) != nil {
            isStretchValid = true
        } else {
            isStretchValid = false
        }
    }
}

struct ModifyStretchTuningLineDialog_Previews: PreviewProvider {
    static var previews: some View {
        ModifyStretchTuningLineDialog(
            initialUnstretchedFrequency: 440.0,
            initialStretchInCents: 5.0,
            key: 1,
            onDismiss: {},
            onConfirm: { _, _, _ in }
        )
    }
}
