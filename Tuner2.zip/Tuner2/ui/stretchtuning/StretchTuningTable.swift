import SwiftUI

struct StretchTuningTable: View {
    let stretchTuningData: StretchTuning
    let selectedKey: Int?
    let onLineClicked: (Int) -> Void
    let onEditLineClicked: (Int) -> Void
    let onDeleteLineClicked: (Int) -> Void
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Text("Frequency")
                    .font(.caption).bold()
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text("Stretch")
                    .font(.caption).bold()
                    .frame(maxWidth: .infinity, alignment: .trailing)
                Spacer().frame(width: 40) // Space for menu icon
            }
            .padding()
            .background(Color(UIColor.secondarySystemBackground))
            
            // List
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(0..<stretchTuningData.unstretchedFrequencies.count, id: \.self) { index in
                        let freq = stretchTuningData.unstretchedFrequencies[index]
                        let cents = stretchTuningData.stretchInCents[index]
                        
                        // Check for order errors (monotonicity)
                        let errorMessage: String? = (index > 0 && freq <= stretchTuningData.unstretchedFrequencies[index - 1])
                            ? "Frequencies must be strictly increasing"
                            : nil
                        
                        StretchTuningTableLine(
                            frequencyText: String(format: "%.1f Hz", freq),
                            stretchText: String(format: "%.1f ¢", cents),
                            isSelected: index == selectedKey,
                            errorMessage: errorMessage,
                            onEdit: { onEditLineClicked(index) },
                            onDelete: { onDeleteLineClicked(index) }
                        )
                        .contentShape(Rectangle())
                        .onTapGesture {
                            onLineClicked(index)
                        }
                        
                        Divider()
                    }
                }
            }
        }
        .background(Color(UIColor.systemBackground))
        .cornerRadius(8)
        .shadow(radius: 2)
    }
}

struct StretchTuningTable_Previews: PreviewProvider {
    static var previews: some View {
        let tuning = StretchTuning(
            name: "Test",
            description: "",
            unstretchedFrequencies: [440, 439, 880], // Intentional error for preview
            stretchInCents: [0, 5, 10]
        )
        StretchTuningTable(
            stretchTuningData: tuning,
            selectedKey: 1,
            onLineClicked: { _ in },
            onEditLineClicked: { _ in },
            onDeleteLineClicked: { _ in }
        )
        .padding()
    }
}
