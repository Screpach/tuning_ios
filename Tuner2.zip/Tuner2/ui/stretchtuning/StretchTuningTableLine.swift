import SwiftUI

struct StretchTuningTableLine: View {
    let frequencyText: String
    let stretchText: String
    let isSelected: Bool
    let errorMessage: String?
    let onEdit: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                // Frequency Column
                Text(frequencyText)
                    .font(.body)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 12)
                
                // Stretch Column
                Text(stretchText)
                    .font(.body)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    .padding(.vertical, 12)
                
                // Actions Menu
                Menu {
                    Button(action: onEdit) {
                        Label("Edit", systemImage: "pencil")
                    }
                    Button(role: .destructive, action: onDelete) {
                        Label("Delete", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis")
                        .padding()
                        .foregroundColor(.primary)
                }
            }
            .padding(.horizontal)
            .background(isSelected ? Color.blue.opacity(0.1) : Color.clear)
            
            // Error Message Row
            if let error = errorMessage {
                Text(error)
                    .font(.caption)
                    .foregroundColor(.red)
                    .padding(.horizontal)
                    .padding(.bottom, 8)
                    .background(isSelected ? Color.blue.opacity(0.1) : Color.clear)
            }
        }
    }
}

struct StretchTuningTableLine_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            StretchTuningTableLine(
                frequencyText: "440.0 Hz",
                stretchText: "2.5 ¢",
                isSelected: false,
                errorMessage: nil,
                onEdit: {},
                onDelete: {}
            )
            StretchTuningTableLine(
                frequencyText: "440.0 Hz",
                stretchText: "2.5 ¢",
                isSelected: true,
                errorMessage: "Frequencies must be strictly increasing",
                onEdit: {},
                onDelete: {}
            )
        }
    }
}
