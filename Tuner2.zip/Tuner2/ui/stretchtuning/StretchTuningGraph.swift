import SwiftUI

// Assuming these helpers exist from ui/plot conversion or provided context
// If not, simplified local versions/stubs are used to ensure compilation.

struct StretchTuningGraph: View {
    let stretchTuning: StretchTuning
    
    // Viewport state
    @StateObject private var viewPortState = GestureBasedViewPort()
    
    // Highlighted point (if any)
    var highlightedPoint: CGPoint? = nil

    var body: some View {
        GeometryReader { geometry in
            let density = geometry.size.width / 300 // rough approximation for density scaling if needed
            
            // Calculate Graph Data
            let points = zip(stretchTuning.unstretchedFrequencies, stretchTuning.stretchInCents).map { (freq, cents) in
                CGPoint(x: log2(freq), y: cents)
            }
            
            // Calculate Axes Lines (Octaves for X, 5-cent steps for Y)
            let xLines = generateOctaveLines()
            let yLines = generateCentLines()

            Plot(viewPortState: viewPortState) { transformation in
                
                // 1. Grid Lines
                VerticalLines(
                    positions: VerticalLinesPositions.create(xLines),
                    color: .gray.opacity(0.3),
                    lineWidth: 1,
                    transformation: { transformation }
                )
                
                HorizontalLines(
                    positions: HorizontalLinesPositions.create(yLines),
                    color: .gray.opacity(0.3),
                    lineWidth: 1,
                    transformation: { transformation }
                )
                
                // 2. Main Data Line
                Line(
                    coordinates: LineCoordinates(points: points),
                    color: .blue, // Primary color
                    lineWidth: 2,
                    transformation: { transformation }
                )
                
                // 3. Data Points
                Points(
                    coordinates: LineCoordinates(points: points),
                    shape: .circle(size: 6),
                    size: 6,
                    color: .blue,
                    transformation: { transformation }
                )
                
                // 4. Highlighted Point (e.g., active selection)
                if let highlight = highlightedPoint {
                    Point(
                        position: highlight,
                        shape: .circle(size: 12, color: .red),
                        transformation: { transformation }
                    )
                }
            }
            .onAppear {
                // Initialize ViewPort logic
                // e.g. set boundaries based on data min/max
                if let minX = points.map({ $0.x }).min(),
                   let maxX = points.map({ $0.x }).max(),
                   let minY = points.map({ $0.y }).min(),
                   let maxY = points.map({ $0.y }).max() {
                    
                    let paddingX = (maxX - minX) * 0.1
                    let paddingY = (maxY - minY) * 0.1
                    let rect = CGRect(
                        x: minX - paddingX,
                        y: minY - paddingY,
                        width: (maxX - minX) + 2 * paddingX,
                        height: (maxY - minY) + 2 * paddingY
                    )
                    viewPortState.setViewPort(rect, limits: nil)
                }
            }
        }
    }
    
    // Helper to generate vertical lines at octave intervals (log scale)
    private func generateOctaveLines() -> [Float] {
        // Simple example: C0 to C9 approx
        var lines: [Float] = []
        var freq = 16.35
        while freq < 20000 {
            lines.append(Float(log2(freq)))
            freq *= 2
        }
        return lines
    }
    
    // Helper to generate horizontal lines
    private func generateCentLines() -> [Float] {
        return stride(from: -50.0, through: 50.0, by: 10.0).map { Float($0) }
    }
}

// MARK: - Preview
struct StretchTuningGraph_Previews: PreviewProvider {
    static var previews: some View {
        let tuning = StretchTuning(
            name: "Test",
            description: "Description",
            unstretchedFrequencies: [100, 200, 400, 800],
            stretchInCents: [0, 2, 4, 6]
        )
        
        StretchTuningGraph(stretchTuning: tuning)
            .frame(height: 300)
    }
}
