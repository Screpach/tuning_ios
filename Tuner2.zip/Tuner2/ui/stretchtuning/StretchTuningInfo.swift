import SwiftUI

// MARK: - Model Stub
// Included here to serve as the shared data model for the files in this folder
struct StretchTuning: Identifiable {
    let id = UUID()
    var name: String
    var description: String
    var unstretchedFrequencies: [Double]
    var stretchInCents: [Double]
    
    // Keys for editing usually map to indices in a real DB context,
    // here we simulate keys via indices for the UI logic.
    var keys: [Int] {
        return Array(0..<unstretchedFrequencies.count)
    }
}

// MARK: - Main Info View
struct StretchTuningInfo: View {
    @State var stretchTuning: StretchTuning
    
    // State for Dialog
    @State private var showEditDialog = false
    @State private var selectedKeyForEdit: Int? = nil
    @State private var selectedKey: Int? = nil // Highlighted in graph/table
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                // 1. Graph Section (Top half)
                BoxWithConstraints {
                    StretchTuningGraph(
                        stretchTuning: stretchTuning,
                        highlightedPoint: selectedKey != nil ?
                            CGPoint(
                                x: log2(stretchTuning.unstretchedFrequencies[selectedKey!]),
                                y: stretchTuning.stretchInCents[selectedKey!]
                            ) : nil
                    )
                    .frame(height: 300) // Fixed height for graph or flexible
                    .background(Color(UIColor.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .padding()
                }

                // 2. Table Section (Bottom half)
                StretchTuningTable(
                    stretchTuningData: stretchTuning,
                    selectedKey: selectedKey,
                    onLineClicked: { key in
                        selectedKey = key
                    },
                    onEditLineClicked: { key in
                        selectedKeyForEdit = key
                        showEditDialog = true
                    },
                    onDeleteLineClicked: { key in
                        deleteLine(at: key)
                    }
                )
                .padding(.horizontal)
            }
            
            // 3. Floating Action Button
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button(action: {
                        selectedKeyForEdit = nil // Add new
                        showEditDialog = true
                    }) {
                        Image(systemName: "plus")
                            .font(.title2)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .clipShape(Circle())
                            .shadow(radius: 4)
                    }
                    .padding()
                }
            }
            
            // 4. Edit Dialog Overlay
            if showEditDialog {
                ModifyStretchTuningLineDialog(
                    initialUnstretchedFrequency: selectedKeyForEdit != nil ? stretchTuning.unstretchedFrequencies[selectedKeyForEdit!] : nil,
                    initialStretchInCents: selectedKeyForEdit != nil ? stretchTuning.stretchInCents[selectedKeyForEdit!] : nil,
                    key: selectedKeyForEdit ?? -1, // -1 for new
                    onDismiss: { showEditDialog = false },
                    onConfirm: { key, freq, stretch in
                        if key == -1 {
                            // Add logic
                            addLine(freq: freq, stretch: stretch)
                        } else {
                            // Edit logic
                            updateLine(at: key, freq: freq, stretch: stretch)
                        }
                        showEditDialog = false
                    }
                )
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text(stretchTuning.name).font(.headline)
            }
        }
    }
    
    // MARK: - Logic Helpers
    // In a real app, these would modify the ViewModel
    private func deleteLine(at index: Int) {
        guard index < stretchTuning.unstretchedFrequencies.count else { return }
        stretchTuning.unstretchedFrequencies.remove(at: index)
        stretchTuning.stretchInCents.remove(at: index)
        if selectedKey == index { selectedKey = nil }
    }
    
    private func addLine(freq: Double, stretch: Double) {
        // Simple append and sort for demo
        stretchTuning.unstretchedFrequencies.append(freq)
        stretchTuning.stretchInCents.append(stretch)
        sortData()
    }
    
    private func updateLine(at index: Int, freq: Double, stretch: Double) {
        guard index < stretchTuning.unstretchedFrequencies.count else { return }
        stretchTuning.unstretchedFrequencies[index] = freq
        stretchTuning.stretchInCents[index] = stretch
        sortData()
    }
    
    private func sortData() {
        // Zip, sort by freq, unzip
        let combined = zip(stretchTuning.unstretchedFrequencies, stretchTuning.stretchInCents)
            .sorted { $0.0 < $1.0 }
        stretchTuning.unstretchedFrequencies = combined.map { $0.0 }
        stretchTuning.stretchInCents = combined.map { $0.1 }
    }
}

// Helper struct for Layout
struct BoxWithConstraints<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    var body: some View {
        GeometryReader { _ in content }
    }
}

struct StretchTuningInfo_Previews: PreviewProvider {
    static var previews: some View {
        let tuning = StretchTuning(
            name: "Grand Piano",
            description: "Concert Hall",
            unstretchedFrequencies: [27.5, 55.0, 110.0, 220.0, 440.0, 880.0, 1760.0, 3520.0],
            stretchInCents: [-5, -2, 0, 1, 2, 4, 8, 15]
        )
        StretchTuningInfo(stretchTuning: tuning)
    }
}
