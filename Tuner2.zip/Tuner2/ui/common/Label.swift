import SwiftUI

/// General label definition with a background and content.
/// Equivalent to `Label.kt`.
struct CustomLabel<Content: View>: View {
    
    var color: Color = Color.secondary.opacity(0.1)
    var onClick: (() -> Void)? = nil
    @ViewBuilder var content: () -> Content
    
    var body: some View {
        content()
            .padding(8)
            .background(color)
            .clipShape(RoundedRectangle(cornerRadius: 4))
            .onTapGesture {
                onClick?()
            }
    }
}
