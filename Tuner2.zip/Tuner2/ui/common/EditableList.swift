import SwiftUI

/// A generic list component supporting predefined and custom sections.
/// Equivalent to `EditableList.kt`.
struct EditableList<T: Identifiable & Hashable, Content: View>: View {
    
    @ObservedObject var state: EditableListData<T>
    var onActivateItemClicked: (T) -> Void
    var onEditItemClicked: ((T) -> Void)? = nil
    var onDeleteItemClicked: ((T) -> Void)? = nil
    
    // Content builder for the list item content
    @ViewBuilder var itemContent: (T, EditableListItemInfo) -> Content
    
    var body: some View {
        List {
            // 1. Predefined Sections
            if !state.predefinedItems.isEmpty {
                Section(
                    header: EditableListSection(
                        title: state.predefinedSectionTitle,
                        expanded: state.predefinedExpanded,
                        onExpandClicked: state.togglePredefinedExpanded
                    )
                ) {
                    if state.predefinedExpanded {
                        ForEach(state.predefinedItems) { item in
                            renderItem(item)
                        }
                    }
                }
            }
            
            // 2. Custom/Editable Section
            if !state.customItems.isEmpty {
                Section(
                    header: EditableListSection(
                        title: state.customSectionTitle,
                        expanded: state.customExpanded,
                        onExpandClicked: state.toggleCustomExpanded
                    )
                ) {
                    if state.customExpanded {
                        ForEach(state.customItems) { item in
                            renderItem(item)
                        }
                        // Swipe to delete could go here
                    }
                }
            }
        }
        .listStyle(.plain)
    }
    
    private func renderItem(_ item: T) -> some View {
        let isSelected = (state.activeItem == item)
        let info = EditableListItemInfo(isSelected: isSelected)
        
        return EditableListItem(
            isSelected: isSelected,
            onActivate: { onActivateItemClicked(item) },
            onEdit: onEditItemClicked != nil ? { onEditItemClicked?(item) } : nil,
            onDelete: onDeleteItemClicked != nil ? { onDeleteItemClicked?(item) } : nil
        ) {
            itemContent(item, info)
        }
    }
}

// Helper struct for item state
struct EditableListItemInfo {
    let isSelected: Bool
}
