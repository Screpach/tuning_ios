import SwiftUI

/// A collapsible section header.
/// Equivalent to `EditableListSection.kt`.
struct EditableListSection: View {
    
    let title: String
    let expanded: Bool
    let onExpandClicked: (Bool) -> Void
    
    var body: some View {
        Button(action: { onExpandClicked(!expanded) }) {
            HStack {
                Text(title)
                    .font(.headline)
                    .foregroundStyle(.primary)
                
                Spacer()
                
                Image(systemName: expanded ? "chevron.up" : "chevron.down")
                    .foregroundStyle(.secondary)
            }
            .padding(.vertical, 8)
            .contentShape(Rectangle()) // Make full width tappable
        }
        .buttonStyle(.plain)
    }
}
