import SwiftUI

/// Overflow menu for the top bar (Export, Load, Settings).
/// Equivalent to `EditableListOverflowMenu.kt`.
struct EditableListOverflowMenu: View {
    
    var onExportClicked: () -> Void
    var onImportClicked: () -> Void
    var onSettingsClicked: (() -> Void)? = nil
    
    var body: some View {
        Menu {
            Button(action: onExportClicked) {
                Label(String(localized: "archive", defaultValue: "Archive/Share"), systemImage: "square.and.arrow.up")
            }
            
            Button(action: onImportClicked) {
                Label(String(localized: "load_from_disk", defaultValue: "Load from disk"), systemImage: "square.and.arrow.down")
            }
            
            if let onSettings = onSettingsClicked {
                Divider()
                Button(action: onSettings) {
                    Label(String(localized: "settings", defaultValue: "Settings"), systemImage: "gear")
                }
            }
        } label: {
            Image(systemName: "ellipsis.circle")
        }
    }
}
