import SwiftUI

/// A list item with selection highlight and a context menu (overflow).
/// Equivalent to `EditableListItem.kt`.
struct EditableListItem<Content: View>: View {
    
    let isSelected: Bool
    let onActivate: () -> Void
    let onEdit: (() -> Void)?
    let onDelete: (() -> Void)?
    
    @ViewBuilder var content: () -> Content
    
    var body: some View {
        HStack {
            // Content Area (Click to Activate)
            Button(action: onActivate) {
                content()
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .buttonStyle(.plain) // remove default button styling
            
            // Overflow Menu (if edit/delete actions exist)
            if onEdit != nil || onDelete != nil {
                Menu {
                    if let onEdit = onEdit {
                        Button(action: onEdit) {
                            Label("Edit", systemImage: "pencil")
                        }
                    }
                    if let onDelete = onDelete {
                        Button(role: .destructive, action: onDelete) {
                            Label("Delete", systemImage: "trash")
                        }
                    }
                } label: {
                    Image(systemName: "ellipsis")
                        .padding()
                }
            }
        }
        .padding(.vertical, 4)
        .background(isSelected ? Color.accentColor.opacity(0.15) : Color.clear)
        .cornerRadius(8)
    }
}
