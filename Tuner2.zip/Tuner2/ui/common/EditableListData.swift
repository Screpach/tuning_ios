import Foundation
import Combine

/// Data model for an editable list (e.g. instruments, temperaments).
/// Equivalent to `EditableListData.kt`.
@MainActor
class EditableListData<T: Identifiable & Hashable>: ObservableObject {
    
    // Predefined Section
    let predefinedSectionTitle: String
    let predefinedItems: [T]
    @Published var predefinedExpanded: Bool
    let togglePredefinedExpanded: (Bool) -> Void
    
    // Custom Section
    let customSectionTitle: String
    @Published var customItems: [T]
    @Published var customExpanded: Bool
    let toggleCustomExpanded: (Bool) -> Void
    let setNewItems: ([T]) -> Void
    
    // Active Selection
    @Published var activeItem: T?
    
    init(
        predefinedSectionTitle: String,
        predefinedItems: [T],
        predefinedExpanded: Bool,
        togglePredefinedExpanded: @escaping (Bool) -> Void,
        customSectionTitle: String,
        customItems: [T],
        customExpanded: Bool,
        toggleCustomExpanded: @escaping (Bool) -> Void,
        setNewItems: @escaping ([T]) -> Void,
        activeItem: T? = nil
    ) {
        self.predefinedSectionTitle = predefinedSectionTitle
        self.predefinedItems = predefinedItems
        self.predefinedExpanded = predefinedExpanded
        self.togglePredefinedExpanded = togglePredefinedExpanded
        
        self.customSectionTitle = customSectionTitle
        self.customItems = customItems
        self.customExpanded = customExpanded
        self.toggleCustomExpanded = toggleCustomExpanded
        self.setNewItems = setNewItems
        self.activeItem = activeItem
    }
}
