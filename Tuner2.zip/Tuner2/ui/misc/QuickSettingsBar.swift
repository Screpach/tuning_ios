import SwiftUI

/// Bottom bar for quick access to tuner settings.
/// Equivalent to `QuickSettingsBar.kt`.
struct QuickSettingsBar: View {
    
    let musicalScale: MusicalScale2
    let notePrintOptions: NotePrintOptions
    var onSharpFlatClicked: () -> Void
    var onRootNoteClicked: (() -> Void)? = nil // Added for completeness if needed
    
    var body: some View {
        HStack {
            // 1. Root Note Indicator (if non-equal temperament)
            if let root = musicalScale.rootNote {
                Button(action: { onRootNoteClicked?() }) {
                    VStack(spacing: 2) {
                        Text(String(localized: "root_note", defaultValue: "Root"))
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                        Text("\(root.base.rawValue)") // Simplified note print
                            .font(.body)
                            .bold()
                    }
                }
                .padding(.horizontal)
            }
            
            Spacer()
            
            // 2. Temperament Name
            VStack(spacing: 2) {
                Text(String(localized: "temperament", defaultValue: "Temperament"))
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                Text(musicalScale.temperament.name.getString())
                    .font(.caption)
                    .lineLimit(1)
            }
            
            Spacer()
            
            // 3. Sharp/Flat Toggle
            Button(action: onSharpFlatClicked) {
                Image(systemName: "music.note") // Placeholder icon
                    .imageScale(.large)
                    .padding()
            }
        }
        .padding(8)
        .background(MaterialTheme.colorScheme.surface)
        .border(width: 1, edges: [.top], color: .secondary.opacity(0.2))
    }
}
