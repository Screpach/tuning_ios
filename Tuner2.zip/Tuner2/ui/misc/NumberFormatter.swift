import SwiftUI

/// Formats numbers with adaptive precision based on magnitude.
/// Equivalent to `NumberFormatter.kt`.
class TuningNumberFormatter {
    
    private let formatter: NumberFormatter
    private let precision: Int
    
    init(locale: Locale = .current, precision: Int = 4) {
        self.precision = precision
        self.formatter = NumberFormatter()
        self.formatter.locale = locale
        self.formatter.numberStyle = .decimal
        self.formatter.usesGroupingSeparator = false // Usually scientific apps avoid grouping in small fields
        self.formatter.roundingMode = .halfEven
    }
    
    func format(_ number: Float) -> String {
        return format(Double(number))
    }
    
    func format(_ number: Double) -> String {
        // Calculate needed fraction digits
        // logic: precision - floor(log10(number))
        // e.g. number=440 (log=2) -> precision(4) - 2 = 2 fraction digits -> "440.00"
        
        let magnitude = floor(log10(abs(number)))
        let fractionDigits = max(0, precision - Int(magnitude))
        
        formatter.maximumFractionDigits = fractionDigits
        formatter.minimumFractionDigits = 0 // Optional: match Kotlin behavior
        
        return formatter.string(from: NSNumber(value: number)) ?? "\(number)"
    }
}

// Hook for SwiftUI
struct NumberFormatterKey: EnvironmentKey {
    static let defaultValue = TuningNumberFormatter()
}

extension EnvironmentValues {
    var tuningNumberFormatter: TuningNumberFormatter {
        get { self[NumberFormatterKey.self] }
        set { self[NumberFormatterKey.self] = newValue }
    }
}
