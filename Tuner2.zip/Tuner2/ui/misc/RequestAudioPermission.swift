import SwiftUI
import AVFoundation

/// Component that ensures audio permissions are granted.
/// Equivalent to `RequestAudioPermission.kt`.
///
/// Usage:
/// ```swift
/// AudioPermissionGate {
///     TunerScreen(...)
/// }
/// ```
struct AudioPermissionGate<Content: View>: View {
    
    @ViewBuilder var content: () -> Content
    
    @State private var permissionStatus: AVAuthorizationStatus = .notDetermined
    
    var body: some View {
        Group {
            switch permissionStatus {
            case .authorized:
                content()
            case .denied, .restricted:
                PermissionDeniedView()
            case .notDetermined:
                Button("Grant Microphone Access") {
                    requestPermission()
                }
            @unknown default:
                Text("Unknown permission state")
            }
        }
        .onAppear {
            checkPermission()
        }
    }
    
    private func checkPermission() {
        permissionStatus = AVCaptureDevice.authorizationStatus(for: .audio)
    }
    
    private func requestPermission() {
        AVCaptureDevice.requestAccess(for: .audio) { granted in
            DispatchQueue.main.async {
                self.checkPermission()
            }
        }
    }
}

struct PermissionDeniedView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "mic.slash.circle")
                .font(.system(size: 60))
                .foregroundStyle(.red)
            Text("Microphone Access Required")
                .font(.headline)
            Text("Please enable microphone access in Settings to use the tuner.")
                .multilineTextAlignment(.center)
                .padding()
            Button("Open Settings") {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            }
        }
    }
}
