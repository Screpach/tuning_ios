import SwiftUI

/// Wrapper layout providing standard bars and action mode support.
/// Equivalent to `TunerScaffold.kt`.
struct TunerScaffold<Content: View, ActionModeTools: View>: View {
    
    var actionModeActive: Bool
    var actionModeTitle: String
    var onActionModeFinished: () -> Void
    @ViewBuilder var actionModeTools: () -> ActionModeTools
    
    // Standard content
    @ViewBuilder var content: () -> Content
    
    var body: some View {
        VStack(spacing: 0) {
            // Custom Top Bar (if action mode active)
            if actionModeActive {
                HStack {
                    Button(action: onActionModeFinished) {
                        Image(systemName: "xmark")
                            .foregroundStyle(.primary)
                    }
                    Text(actionModeTitle)
                        .font(.headline)
                        .padding(.leading)
                    
                    Spacer()
                    
                    actionModeTools()
                }
                .padding()
                .background(Color.accentColor.opacity(0.1))
            }
            
            // Main Content
            content()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}
