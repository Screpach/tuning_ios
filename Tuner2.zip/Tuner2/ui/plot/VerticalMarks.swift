import SwiftUI

struct VerticalMark: Identifiable {
    let id = UUID()
    let position: Float
    let settings: Settings
    // Content is typically a label/View, handled via view composition in Swift
    
    struct Settings {
        var lineWidth: CGFloat = 1
        var labelPosition: CGFloat = 0.95 // Normalized 0-1 from top
        var anchor: Anchor = .north
        var lineColor: Color = .gray
        var screenOffset: CGPoint = .zero
    }
}

struct VerticalMarks: View {
    let marks: [VerticalMark]
    let clipLabelsToWindow: Bool
    let sameSizeLabels: Bool
    let clipped: Bool
    let transformation: () -> Transformation
    
    var body: some View {
        ZStack {
            // 1. Lines
            if clipped {
                Canvas { context, size in
                    let t = transformation()
                    let vp = t.viewPortScreen
                    
                    for mark in marks {
                        let xRaw = Double(mark.position)
                        let xScreen = t.toScreen(CGPoint(x: xRaw, y: 0)).x
                        
                        // Check if visible
                        if xScreen >= vp.minX && xScreen <= vp.maxX {
                            let p1 = CGPoint(x: xScreen, y: vp.minY)
                            let p2 = CGPoint(x: xScreen, y: vp.maxY)
                            
                            var path = Path()
                            path.move(to: p1)
                            path.addLine(to: p2)
                            
                            context.stroke(path, with: .color(mark.settings.lineColor), lineWidth: mark.settings.lineWidth)
                        }
                    }
                }
            }
            
            // 2. Labels
            if clipLabelsToWindow == clipped {
                ForEach(marks) { mark in
                    let t = transformation()
                    let xRaw = Double(mark.position)
                    let xScreen = t.toScreen(CGPoint(x: xRaw, y: 0)).x
                    let vp = t.viewPortScreen
                    
                    if !clipLabelsToWindow || (xScreen >= vp.minX && xScreen <= vp.maxX) {
                        let yPos = vp.minY + mark.settings.labelPosition * vp.height + mark.settings.screenOffset.y
                        let xPos = xScreen + mark.settings.screenOffset.x
                        
                        // Placeholder Text. In real usage, 'content' would be passed.
                        Text(String(format: "%.0f", mark.position))
                            .font(.caption)
                            .position(
                                mark.settings.anchor.place(
                                    x: xPos,
                                    y: yPos,
                                    w: 30,
                                    h: 15,
                                    horizontalLineWidth: 0,
                                    verticalLineWidth: mark.settings.lineWidth
                                )
                            )
                    }
                }
            }
        }
    }
}
