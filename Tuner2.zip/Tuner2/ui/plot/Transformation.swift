import SwiftUI

struct Transformation {
    let viewPortScreen: CGRect
    let viewPortRaw: CGRect
    
    // Helper to allow functional creation if needed
    init(viewPortScreen: CGRect, viewPortRaw: CGRect) {
        self.viewPortScreen = viewPortScreen
        self.viewPortRaw = viewPortRaw
    }

    func toScreen(_ point: CGPoint) -> CGPoint {
        let xRatio = viewPortScreen.width / viewPortRaw.width
        let yRatio = viewPortScreen.height / viewPortRaw.height
        return CGPoint(
            x: viewPortScreen.minX + (point.x - viewPortRaw.minX) * xRatio,
            y: viewPortScreen.minY + (point.y - viewPortRaw.minY) * yRatio
        )
    }
    
    func toScreen(_ rect: CGRect) -> CGRect {
        let p1 = toScreen(CGPoint(x: rect.minX, y: rect.minY))
        let p2 = toScreen(CGPoint(x: rect.maxX, y: rect.maxY))
        return CGRect(x: p1.x, y: p1.y, width: p2.x - p1.x, height: p2.y - p1.y)
    }

    func toRaw(_ point: CGPoint) -> CGPoint {
        let xRatio = viewPortRaw.width / viewPortScreen.width
        let yRatio = viewPortRaw.height / viewPortScreen.height
        return CGPoint(
            x: viewPortRaw.minX + (point.x - viewPortScreen.minX) * xRatio,
            y: viewPortRaw.minY + (point.y - viewPortScreen.minY) * yRatio
        )
    }
    
    func toRaw(_ velocity: CGSize) -> CGSize {
        // Velocity does not depend on the origin offset, only scale
        let xRatio = viewPortRaw.width / viewPortScreen.width
        let yRatio = viewPortRaw.height / viewPortScreen.height
        return CGSize(width: velocity.width * xRatio, height: velocity.height * yRatio)
    }
}
