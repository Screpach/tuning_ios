import Foundation

struct TicksRange {
    let level: Int
    let indexBegin: Int
    let indexEnd: Int
}

protocol TickLevel {
    func getTicksRange(
        startValue: Float,
        endValue: Float,
        maxNumTicks: Int,
        labelSizeRaw: Float
    ) -> TicksRange

    func getTickValue(level: Int, index: Int) -> Float
}

// MARK: - Explicit Ranges Implementation
class TickLevelExplicitRanges: TickLevel {
    private let ticks: [[Float]]
    private let minimumDistance: [Float]

    init(ticks: [[Float]]) {
        self.ticks = ticks
        
        // Pre-calculate minimum distances
        var computedMinDist: [Float] = []
        for levelTicks in ticks {
            if levelTicks.count > 1 {
                let dist = (levelTicks.last! - levelTicks.first!) / Float(levelTicks.count - 1)
                computedMinDist.append(dist)
            } else {
                computedMinDist.append(Float.infinity)
            }
        }
        self.minimumDistance = computedMinDist
    }

    func getTicksRange(startValue: Float, endValue: Float, maxNumTicks: Int, labelSizeRaw: Float) -> TicksRange {
        let minimumAllowedDistance = abs(endValue - startValue) / Float(maxNumTicks + 1)
        
        var level = 0
        for l in (0..<ticks.count).reversed() {
            level = l
            if minimumDistance[l] > minimumAllowedDistance {
                break
            }
        }
        
        // Binary search for indices (Swift equivalent of Kotlin's binarySearch)
        let levelTicks = ticks[level]
        
        let startTarget = startValue - labelSizeRaw
        var iBegin = 0
        if let idx = levelTicks.firstIndex(where: { $0 >= startTarget }) {
            iBegin = idx
        } else {
            iBegin = levelTicks.count
        }
        
        let endTarget = endValue + labelSizeRaw
        var iEnd = 0
        if let idx = levelTicks.firstIndex(where: { $0 > endTarget }) {
            iEnd = idx - 1
        } else {
            iEnd = levelTicks.count - 1
        }
        // Clamp logic to ensure valid range
        if iEnd < iBegin { iEnd = iBegin - 1 }

        return TicksRange(level: level, indexBegin: iBegin, indexEnd: iEnd)
    }

    func getTickValue(level: Int, index: Int) -> Float {
        guard level >= 0 && level < ticks.count, index >= 0 && index < ticks[level].count else { return 0 }
        return ticks[level][index]
    }
}

// MARK: - Delta Based Implementation
class TickLevelDeltaBased: TickLevel {
    private let deltas: [Float]

    init(deltas: [Float]) {
        self.deltas = deltas
    }

    func getTicksRange(startValue: Float, endValue: Float, maxNumTicks: Int, labelSizeRaw: Float) -> TicksRange {
        let minimumAllowedDistance = abs(endValue - startValue) / Float(maxNumTicks + 1)
        
        // Find suitable delta
        // Kotlin binary search returns (-insertionPoint - 1) if not found.
        // We look for the first delta >= minimumAllowedDistance
        var deltaIndex = deltas.count - 1
        if let idx = deltas.firstIndex(where: { $0 >= minimumAllowedDistance }) {
            deltaIndex = idx
        }
        let delta = deltas[deltaIndex]

        let iBegin = Int(floor((startValue - labelSizeRaw) / delta))
        let iEnd = Int(ceil((endValue + labelSizeRaw) / delta))

        return TicksRange(level: deltaIndex, indexBegin: iBegin, indexEnd: iEnd)
    }

    func getTickValue(level: Int, index: Int) -> Float {
        guard level >= 0 && level < deltas.count else { return 0 }
        return Float(index) * deltas[level]
    }
}
