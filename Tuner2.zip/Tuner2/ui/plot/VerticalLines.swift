import SwiftUI

struct VerticalLinesPositions {
    let xValues: [Float]
    
    static func create(_ values: [Float]) -> VerticalLinesPositions {
        return VerticalLinesPositions(xValues: values)
    }
}

struct VerticalLines: View {
    let positions: VerticalLinesPositions
    let color: Color
    let lineWidth: CGFloat
    let transformation: () -> Transformation
    
    var body: some View {
        Canvas { context, size in
            let t = transformation()
            let viewPort = t.viewPortScreen
            
            for xVal in positions.xValues {
                let screenPoint = t.toScreen(CGPoint(x: Double(xVal), y: 0))
                
                // Draw vertical line
                let p1 = CGPoint(x: screenPoint.x, y: viewPort.minY)
                let p2 = CGPoint(x: screenPoint.x, y: viewPort.maxY)
                
                var path = Path()
                path.move(to: p1)
                path.addLine(to: p2)
                
                context.stroke(path, with: .color(color), lineWidth: lineWidth)
            }
        }
    }
}
