import SwiftUI

// Internal logic to mirror Kotlin's caching strategy within SwiftUI's declarative nature
struct Points: View {
    let coordinates: LineCoordinates
    let shape: PointShape
    let size: CGFloat
    let color: Color
    let transformation: () -> Transformation
    
    var body: some View {
        Canvas { context, canvasSize in
            let t = transformation()
            let vp = t.viewPortScreen
            
            // In strict SwiftUI, we re-calculate positions on render.
            // For thousands of points, one might use a custom Shape or Metal, but Canvas is efficient.
            for point in coordinates.points {
                let screenPos = t.toScreen(point)
                
                // Simple culling
                if screenPos.x >= vp.minX - size && screenPos.x <= vp.maxX + size &&
                   screenPos.y >= vp.minY - size && screenPos.y <= vp.maxY + size {
                    
                    shape.draw(&context, screenPos, size, color)
                }
            }
        }
    }
}
