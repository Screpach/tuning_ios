import SwiftUI

struct HorizontalMark: Identifiable {
    let id = UUID()
    let position: Float
    let settings: Settings
    // Content is a ViewBuilder in usage, but here we treat it as data or closure
    // For simplicity in this port, we'll assume a simple text label or generic view
    
    struct Settings {
        var lineWidth: CGFloat = 1
        var labelPosition: CGFloat = 0.5
        var anchor: Anchor = .center
        var lineColor: Color = .gray
        var screenOffset: CGPoint = .zero
    }
}

struct HorizontalMarks: View {
    let marks: [HorizontalMark]
    let clipLabelsToWindow: Bool
    let sameSizeLabels: Bool
    let clipped: Bool
    let transformation: () -> Transformation
    
    var body: some View {
        ZStack {
            // 1. Lines
            if clipped {
                Canvas { context, size in
                    let t = transformation()
                    let vp = t.viewPortScreen
                    
                    for mark in marks {
                        let yRaw = Double(mark.position)
                        let yScreen = t.toScreen(CGPoint(x: 0, y: yRaw)).y
                        
                        let p1 = CGPoint(x: vp.minX, y: yScreen)
                        let p2 = CGPoint(x: vp.maxX, y: yScreen)
                        
                        var path = Path()
                        path.move(to: p1)
                        path.addLine(to: p2)
                        
                        context.stroke(path, with: .color(mark.settings.lineColor), lineWidth: mark.settings.lineWidth)
                    }
                }
            }
            
            // 2. Labels
            if clipLabelsToWindow == clipped {
                ForEach(marks) { mark in
                    let t = transformation()
                    let yRaw = Double(mark.position)
                    let yScreen = t.toScreen(CGPoint(x: 0, y: yRaw)).y
                    let vp = t.viewPortScreen
                    
                    // Check visibility
                    if !clipLabelsToWindow || (yScreen >= vp.minY && yScreen <= vp.maxY) {
                        let xPos = vp.minX + mark.settings.labelPosition * vp.width + mark.settings.screenOffset.x
                        let yPos = yScreen + mark.settings.screenOffset.y
                        
                        // Placement logic would go here.
                        // In SwiftUI, we can just position a Text/View
                        Text(String(format: "%.0f", mark.position)) // Placeholder content
                            .font(.caption)
                            .position(
                                mark.settings.anchor.place(
                                    x: xPos,
                                    y: yPos,
                                    w: 30, // Estimated width
                                    h: 15
                                )
                            )
                    }
                }
            }
        }
    }
}
