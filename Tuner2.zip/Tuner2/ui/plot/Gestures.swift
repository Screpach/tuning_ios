import SwiftUI

// Combined Gesture Modifier
struct PlotGestureModifier: ViewModifier {
    @ObservedObject var state: GestureBasedViewPort
    let transformation: () -> Transformation
    let limits: () -> CGRect?
    
    // Zoom/Pan State
    @State private var currentScale: CGFloat = 1.0
    @State private var currentOffset: CGSize = .zero
    @State private var startViewPort: CGRect = .zero
    
    func body(content: Content) -> some View {
        content
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        if currentOffset == .zero {
                            // Gesture Started
                            state.setViewPort(state.viewPort, limits: nil)
                            startViewPort = state.viewPort
                        }
                        
                        let t = transformation()
                        // Calculate delta in raw coordinates
                        let startRaw = t.toRaw(value.startLocation)
                        let currentRaw = t.toRaw(value.location)
                        let diffX = startRaw.x - currentRaw.x
                        let diffY = startRaw.y - currentRaw.y
                        
                        let newOrigin = CGPoint(
                            x: startViewPort.minX + diffX,
                            y: startViewPort.minY + diffY
                        )
                        
                        let candidate = CGRect(origin: newOrigin, size: startViewPort.size)
                        state.setViewPort(candidate, limits: limits())
                        
                        currentOffset = value.translation
                    }
                    .onEnded { value in
                        // Fling Logic
                        let t = transformation()
                        // Estimate velocity (points per second)
                        let velocity = CGSize(
                            width: value.predictedEndTranslation.width - value.translation.width,
                            height: value.predictedEndTranslation.height - value.translation.height
                        )
                        // Scale velocity to raw units roughly
                        // Note: Accurate velocity mapping requires time-deltas which DragGesture doesn't provide easily
                        // We use a simplified mapping here.
                        let velocityRaw = CGSize(
                            width: velocity.width * (t.viewPortRaw.width / t.viewPortScreen.width),
                            height: velocity.height * (t.viewPortRaw.height / t.viewPortScreen.height)
                        )
                        
                        state.flingViewPort(velocity: velocityRaw, limits: limits())
                        currentOffset = .zero
                    }
            )
            // Note: MagnificationGesture handling would be added here for Zoom
            // Simulating "detectPanZoomFling" fully in SwiftUI requires simultaneous gesture handling
    }
}

extension View {
    func plotGestures(state: GestureBasedViewPort, transformation: @escaping () -> Transformation, limits: @escaping () -> CGRect?) -> some View {
        self.modifier(PlotGestureModifier(state: state, transformation: transformation, limits: limits))
    }
}
