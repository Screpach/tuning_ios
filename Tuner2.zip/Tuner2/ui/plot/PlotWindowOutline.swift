import SwiftUI

struct PlotWindowOutline {
    var lineWidth: CGFloat = 1.0
    var cornerRadius: CGFloat = 8.0
    var color: Color? = nil // Color.Unspecified equivalent
}

extension View {
    func createPlotWindowOutline(outline: PlotWindowOutline, viewPort: CGRect) -> some View {
        self.overlay(
            RoundedRectangle(cornerRadius: outline.cornerRadius)
                .stroke(outline.color ?? .primary, lineWidth: outline.lineWidth)
                .frame(width: viewPort.width - outline.lineWidth, height: viewPort.height - outline.lineWidth)
                .position(x: viewPort.midX, y: viewPort.midY)
                .allowsHitTesting(false)
        )
    }
}
