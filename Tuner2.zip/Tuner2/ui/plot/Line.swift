import SwiftUI

struct LineCoordinates {
    let points: [CGPoint]
    
    static func create(x: [Float], y: [Float]) -> LineCoordinates {
        var pts: [CGPoint] = []
        let count = min(x.count, y.count)
        for i in 0..<count {
            pts.append(CGPoint(x: Double(x[i]), y: Double(y[i])))
        }
        return LineCoordinates(points: pts)
    }
    
    // Helper to support lambda providers from Kotlin
    static func create(size: Int, x: (Int) -> Float, y: (Int) -> Float) -> LineCoordinates {
        var pts: [CGPoint] = []
        for i in 0..<size {
            pts.append(CGPoint(x: Double(x(i)), y: Double(y(i))))
        }
        return LineCoordinates(points: pts)
    }
}

struct Line: View {
    let coordinates: LineCoordinates
    let color: Color
    let lineWidth: CGFloat
    let transformation: () -> Transformation
    
    var body: some View {
        Canvas { context, size in
            let t = transformation()
            var path = Path()
            
            if let first = coordinates.points.first {
                path.move(to: t.toScreen(first))
                
                for point in coordinates.points.dropFirst() {
                    path.addLine(to: t.toScreen(point))
                }
            }
            
            context.stroke(path, with: .color(color), lineWidth: lineWidth)
        }
    }
}
