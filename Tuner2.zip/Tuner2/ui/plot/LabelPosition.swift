import SwiftUI

enum Anchor {
    case northWest, north, northEast
    case west, center, east
    case southWest, south, southEast
    
    func place(x: CGFloat, y: CGFloat, w: CGFloat, h: CGFloat) -> CGPoint {
        switch self {
        case .northWest: return CGPoint(x: x, y: y)
        case .north:     return CGPoint(x: x - 0.5 * w, y: y)
        case .northEast: return CGPoint(x: x - w, y: y)
        case .west:      return CGPoint(x: x, y: y - 0.5 * h)
        case .center:    return CGPoint(x: x - 0.5 * w, y: y - 0.5 * h)
        case .east:      return CGPoint(x: x - w, y: y - 0.5 * h)
        case .southWest: return CGPoint(x: x, y: y - h)
        case .south:     return CGPoint(x: x - 0.5 * w, y: y - h)
        case .southEast: return CGPoint(x: x - w, y: y - h)
        }
    }
    
    func place(x: CGFloat, y: CGFloat, w: CGFloat, h: CGFloat, horizontalLineWidth: CGFloat, verticalLineWidth: CGFloat) -> CGPoint {
        let hL = 0.5 * horizontalLineWidth
        let vL = 0.5 * verticalLineWidth
        
        // Note: The logic below approximates the padding logic from the original snippet
        switch self {
        case .northWest: return CGPoint(x: x + vL, y: y + hL)
        case .north:     return CGPoint(x: x - 0.5 * w, y: y + hL)
        case .northEast: return CGPoint(x: x - w - vL, y: y + hL)
        case .west:      return CGPoint(x: x + vL, y: y - 0.5 * h)
        case .center:    return CGPoint(x: x - 0.5 * w, y: y - 0.5 * h)
        case .east:      return CGPoint(x: x - w - vL, y: y - 0.5 * h)
        case .southWest: return CGPoint(x: x + vL, y: y - h - hL)
        case .south:     return CGPoint(x: x - 0.5 * w, y: y - h - hL)
        case .southEast: return CGPoint(x: x - w - vL, y: y - h - hL)
        }
    }
}
