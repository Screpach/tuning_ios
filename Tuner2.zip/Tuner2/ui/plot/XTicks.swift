import SwiftUI

struct XTicks: View {
    let tickLevel: TickLevel
    let maxLabelWidth: CGFloat
    
    var anchor: Anchor = .center
    var verticalLabelPosition: CGFloat = 0.5 // Relative to ViewPort
    var lineWidth: CGFloat = 1.0
    var lineColor: Color = .primary
    var screenOffset: CGPoint = .zero
    var maxNumLabels: Int = -1
    var clipLabelToPlotWindow: Bool = true
    var transformation: () -> Transformation
    var clipped: Bool
    
    // In Kotlin, 'label' is a Composable lambda. Here we can use a closure or default text.
    // For translation, we'll render default text or accept a formatter.
    
    var body: some View {
        ZStack {
            // 1. Ticks Lines
            if clipped {
                Canvas { context, size in
                    let t = transformation()
                    let vp = t.viewPortScreen
                    
                    let maxLabels = (maxNumLabels > 0) ? maxNumLabels : Int(vp.width / maxLabelWidth)
                    
                    let range = tickLevel.getTicksRange(
                        startValue: Float(t.viewPortRaw.minX),
                        endValue: Float(t.viewPortRaw.maxX),
                        maxNumTicks: maxLabels,
                        labelSizeRaw: 0 // Simplification
                    )
                    
                    for i in range.indexBegin...range.indexEnd {
                        let val = tickLevel.getTickValue(level: range.level, index: i)
                        let xScreen = t.toScreen(CGPoint(x: Double(val), y: 0)).x
                        
                        let p1 = CGPoint(x: xScreen, y: vp.minY)
                        let p2 = CGPoint(x: xScreen, y: vp.maxY)
                        
                        var path = Path()
                        path.move(to: p1)
                        path.addLine(to: p2)
                        
                        context.stroke(path, with: .color(lineColor), lineWidth: lineWidth)
                    }
                }
            }
            
            // 2. Labels
            if clipLabelsToWindow == clipped {
                XTickLabels(
                    tickLevel: tickLevel,
                    maxLabelWidth: maxLabelWidth,
                    anchor: anchor,
                    verticalLabelPosition: verticalLabelPosition,
                    screenOffset: screenOffset,
                    maxNumLabels: maxNumLabels,
                    transformation: transformation
                )
            }
        }
    }
}

// Separate View for Labels to handle layout
struct XTickLabels: View {
    let tickLevel: TickLevel
    let maxLabelWidth: CGFloat
    let anchor: Anchor
    let verticalLabelPosition: CGFloat
    let screenOffset: CGPoint
    let maxNumLabels: Int
    let transformation: () -> Transformation
    
    var body: some View {
        GeometryReader { geometry in
            let t = transformation()
            let vp = t.viewPortScreen
            let maxLabels = (maxNumLabels > 0) ? maxNumLabels : Int(vp.width / maxLabelWidth)
            
            let range = tickLevel.getTicksRange(
                startValue: Float(t.viewPortRaw.minX),
                endValue: Float(t.viewPortRaw.maxX),
                maxNumTicks: maxLabels,
                labelSizeRaw: 0
            )
            
            ForEach(range.indexBegin...range.indexEnd, id: \.self) { i in
                let val = tickLevel.getTickValue(level: range.level, index: i)
                let xScreen = t.toScreen(CGPoint(x: Double(val), y: 0)).x
                
                // Visibility Check
                if xScreen >= vp.minX - maxLabelWidth && xScreen <= vp.maxX + maxLabelWidth {
                    Text("\(Int(val))") // Simplification: using Int value as label
                        .font(.caption)
                        .position(
                            anchor.place(
                                x: xScreen + screenOffset.x,
                                y: vp.minY + verticalLabelPosition * vp.height + screenOffset.y,
                                w: maxLabelWidth,
                                h: 20 // Approx height
                            )
                        )
                }
            }
        }
    }
}
