import SwiftUI

struct PointShape {
    // In Kotlin this returned a lambda `DrawScope.() -> Unit`
    // In Swift, we can define a closure that takes a Context and draws
    let draw: (inout GraphicsContext, CGPoint, CGFloat, Color) -> Void
    
    static func circle(size: CGFloat, color: Color? = nil) -> PointShape {
        return PointShape { context, center, _, explicitColor in
            let r = size / 2.0
            let rect = CGRect(x: center.x - r, y: center.y - r, width: size, height: size)
            context.fill(Path(ellipseIn: rect), with: .color(color ?? explicitColor))
        }
    }
    
    static func circleWithTriangle(size: CGFloat, color: Color? = nil) -> PointShape {
         return PointShape { context, center, _, explicitColor in
             let r = size / 2.0
             let rect = CGRect(x: center.x - r, y: center.y - r, width: size, height: size)
             context.fill(Path(ellipseIn: rect), with: .color(color ?? explicitColor))
             
             // Triangle pointing up
             let rTri = 1.4 * r
             let dy = -1.6 * r
             var path = Path()
             path.move(to: CGPoint(x: center.x - rTri, y: center.y + dy))
             path.addLine(to: CGPoint(x: center.x + rTri, y: center.y + dy))
             path.addLine(to: CGPoint(x: center.x, y: center.y - rTri + dy))
             path.closeSubpath()
             
             context.fill(path, with: .color(color ?? explicitColor))
         }
    }
    
    static func circleWithDownwardTriangle(size: CGFloat, color: Color? = nil) -> PointShape {
         return PointShape { context, center, _, explicitColor in
             let r = size / 2.0
             let rect = CGRect(x: center.x - r, y: center.y - r, width: size, height: size)
             context.fill(Path(ellipseIn: rect), with: .color(color ?? explicitColor))
             
             // Triangle pointing down
             let rTri = 1.4 * r
             let dy = 1.6 * r
             var path = Path()
             path.move(to: CGPoint(x: center.x - rTri, y: center.y + dy))
             path.addLine(to: CGPoint(x: center.x + rTri, y: center.y + dy))
             path.addLine(to: CGPoint(x: center.x, y: center.y + rTri + dy))
             path.closeSubpath()
             
             context.fill(path, with: .color(color ?? explicitColor))
         }
    }
}

struct Point: View {
    let position: CGPoint
    let shape: PointShape
    let transformation: () -> Transformation
    var color: Color = .primary
    var size: CGFloat = 10
    
    var body: some View {
        Canvas { context, size in
            let t = transformation()
            let screenPos = t.toScreen(position)
            shape.draw(&context, screenPos, self.size, color)
        }
    }
}
