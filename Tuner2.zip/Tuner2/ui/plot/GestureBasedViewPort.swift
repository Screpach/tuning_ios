import SwiftUI

// Internal helper for Transformation if not provided elsewhere
struct Transformation {
    let viewPortScreen: CGRect
    let viewPortRaw: CGRect
    
    func toScreen(_ point: CGPoint) -> CGPoint {
        let xRatio = viewPortScreen.width / viewPortRaw.width
        let yRatio = viewPortScreen.height / viewPortRaw.height
        return CGPoint(
            x: viewPortScreen.minX + (point.x - viewPortRaw.minX) * xRatio,
            y: viewPortScreen.minY + (point.y - viewPortRaw.minY) * yRatio
        )
    }
    
    func toRaw(_ point: CGPoint) -> CGPoint {
        let xRatio = viewPortRaw.width / viewPortScreen.width
        let yRatio = viewPortRaw.height / viewPortScreen.height
        return CGPoint(
            x: viewPortRaw.minX + (point.x - viewPortScreen.minX) * xRatio,
            y: viewPortRaw.minY + (point.y - viewPortScreen.minY) * yRatio
        )
    }
}

class GestureBasedViewPort: ObservableObject {
    @Published var viewPort: CGRect
    @Published var isActive: Bool = false
    
    // Animation state
    private var animationTarget: CGRect?
    
    init(isActive: Bool = false, viewPort: CGRect = CGRect(x: 0, y: 0, width: 1, height: 1)) {
        self.isActive = isActive
        self.viewPort = viewPort
    }
    
    func setViewPort(_ value: CGRect, limits: CGRect?) {
        self.isActive = true
        self.viewPort = restrictViewPortToLimits(viewPort: value, viewPortLimits: limits)
    }
    
    func finish() {
        self.isActive = false
    }
    
    func flingViewPort(velocity: CGSize, limits: CGRect?) {
        // Simplified fling logic for Swift translation
        // In a real iOS app, we might rely on ScrollView's native physics or a spring animation
        self.isActive = true
        
        let decelerationRate: CGFloat = 0.998
        let stopThreshold: CGFloat = 0.1
        
        var currentVelocity = velocity
        
        Timer.scheduledTimer(withTimeInterval: 0.016, repeats: true) { timer in
            if !self.isActive || (abs(currentVelocity.width) < stopThreshold && abs(currentVelocity.height) < stopThreshold) {
                timer.invalidate()
                self.isActive = false
                return
            }
            
            let newX = self.viewPort.minX - currentVelocity.width * 0.016
            let newY = self.viewPort.minY - currentVelocity.height * 0.016
            
            let newOrigin = CGPoint(x: newX, y: newY)
            let rawRect = CGRect(origin: newOrigin, size: self.viewPort.size)
            
            self.viewPort = self.restrictViewPortToLimits(viewPort: rawRect, viewPortLimits: limits)
            
            currentVelocity.width *= decelerationRate
            currentVelocity.height *= decelerationRate
        }
    }
    
    private func restrictViewPortToLimits(viewPort: CGRect, viewPortLimits: CGRect?) -> CGRect {
        guard let limits = viewPortLimits else { return viewPort }
        
        var newX = viewPort.minX
        var newY = viewPort.minY
        
        if viewPort.width <= limits.width {
            if newX < limits.minX { newX = limits.minX }
            if newX + viewPort.width > limits.maxX { newX = limits.maxX - viewPort.width }
        }
        
        if viewPort.height <= limits.height {
            if newY < limits.minY { newY = limits.minY }
            if newY + viewPort.height > limits.maxY { newY = limits.maxY - viewPort.height }
        }
        
        return CGRect(x: newX, y: newY, width: viewPort.width, height: viewPort.height)
    }
}
