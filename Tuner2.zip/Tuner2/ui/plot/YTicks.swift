import SwiftUI

struct YTicks: View {
    let tickLevel: TickLevel
    let maxLabelHeight: CGFloat
    
    var anchor: Anchor = .center
    var horizontalLabelPosition: CGFloat = 0.5
    var lineWidth: CGFloat = 1.0
    var lineColor: Color = .primary
    var screenOffset: CGPoint = .zero
    var maxNumLabels: Int = -1
    var clipLabelToPlotWindow: Bool = true
    var transformation: () -> Transformation
    var clipped: Bool
    
    var body: some View {
        ZStack {
            // 1. Ticks Lines
            if clipped {
                Canvas { context, size in
                    let t = transformation()
                    let vp = t.viewPortScreen
                    
                    let maxLabels = (maxNumLabels > 0) ? maxNumLabels : Int(vp.height / maxLabelHeight)
                    
                    let range = tickLevel.getTicksRange(
                        startValue: Float(t.viewPortRaw.minY),
                        endValue: Float(t.viewPortRaw.maxY),
                        maxNumTicks: maxLabels,
                        labelSizeRaw: 0
                    )
                    
                    for i in range.indexBegin...range.indexEnd {
                        let val = tickLevel.getTickValue(level: range.level, index: i)
                        let yScreen = t.toScreen(CGPoint(x: 0, y: Double(val))).y
                        
                        let p1 = CGPoint(x: vp.minX, y: yScreen)
                        let p2 = CGPoint(x: vp.maxX, y: yScreen)
                        
                        var path = Path()
                        path.move(to: p1)
                        path.addLine(to: p2)
                        
                        context.stroke(path, with: .color(lineColor), lineWidth: lineWidth)
                    }
                }
            }
            
            // 2. Labels
            if clipLabelsToWindow == clipped {
                YTickLabels(
                    tickLevel: tickLevel,
                    maxLabelHeight: maxLabelHeight,
                    anchor: anchor,
                    horizontalLabelPosition: horizontalLabelPosition,
                    screenOffset: screenOffset,
                    maxNumLabels: maxNumLabels,
                    transformation: transformation
                )
            }
        }
    }
}

struct YTickLabels: View {
    let tickLevel: TickLevel
    let maxLabelHeight: CGFloat
    let anchor: Anchor
    let horizontalLabelPosition: CGFloat
    let screenOffset: CGPoint
    let maxNumLabels: Int
    let transformation: () -> Transformation
    
    var body: some View {
        GeometryReader { geometry in
            let t = transformation()
            let vp = t.viewPortScreen
            let maxLabels = (maxNumLabels > 0) ? maxNumLabels : Int(vp.height / maxLabelHeight)
            
            let range = tickLevel.getTicksRange(
                startValue: Float(t.viewPortRaw.minY),
                endValue: Float(t.viewPortRaw.maxY),
                maxNumTicks: maxLabels,
                labelSizeRaw: 0
            )
            
            ForEach(range.indexBegin...range.indexEnd, id: \.self) { i in
                let val = tickLevel.getTickValue(level: range.level, index: i)
                let yScreen = t.toScreen(CGPoint(x: 0, y: Double(val))).y
                
                if yScreen >= vp.minY - maxLabelHeight && yScreen <= vp.maxY + maxLabelHeight {
                    Text("\(val, specifier: "%.1f")")
                        .font(.caption)
                        .position(
                            anchor.place(
                                x: vp.minX + horizontalLabelPosition * vp.width + screenOffset.x,
                                y: yScreen + screenOffset.y,
                                w: 40, // Approx width
                                h: maxLabelHeight
                            )
                        )
                }
            }
        }
    }
}
