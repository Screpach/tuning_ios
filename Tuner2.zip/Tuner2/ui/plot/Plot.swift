import SwiftUI

struct Plot: View {
    @ObservedObject var viewPortState: GestureBasedViewPort
    // In Kotlin, 'content' is a @Composable that takes a Transformation.
    // In SwiftUI, we can use a ViewBuilder that accepts a Transformation.
    let content: (Transformation) -> AnyView
    
    init<C: View>(
        viewPortState: GestureBasedViewPort,
        @ViewBuilder content: @escaping (Transformation) -> C
    ) {
        self.viewPortState = viewPortState
        self.content = { t in AnyView(content(t)) }
    }

    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width
            let height = geometry.size.height
            
            // Construct Transformation
            let transform = Transformation(
                viewPortScreen: CGRect(x: 0, y: 0, width: width, height: height),
                viewPortRaw: viewPortState.viewPort
            )
            
            ZStack {
                // The plot content
                content(transform)
                    .frame(width: width, height: height)
                    .clipped()
            }
            // Attach Gestures
            .plotGestures(
                state: viewPortState,
                transformation: { transform },
                limits: { nil } // Can be passed in constructor if needed
            )
        }
    }
}
