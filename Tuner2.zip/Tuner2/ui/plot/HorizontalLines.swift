import SwiftUI

struct HorizontalLinesPositions {
    let yValues: [Float]
    
    static func create(_ values: [Float]) -> HorizontalLinesPositions {
        return HorizontalLinesPositions(yValues: values)
    }
}

struct HorizontalLines: View {
    let positions: HorizontalLinesPositions
    let color: Color
    let lineWidth: CGFloat
    let transformation: () -> Transformation
    
    var body: some View {
        Canvas { context, size in
            let t = transformation()
            let viewPort = t.viewPortScreen
            
            for yVal in positions.yValues {
                // Determine screen Y
                // We create a dummy point with X=0 to get the Y transformation
                let screenPoint = t.toScreen(CGPoint(x: 0, y: Double(yVal)))
                
                // Draw horizontal line across the viewport
                let p1 = CGPoint(x: viewPort.minX, y: screenPoint.y)
                let p2 = CGPoint(x: viewPort.maxX, y: screenPoint.y)
                
                var path = Path()
                path.move(to: p1)
                path.addLine(to: p2)
                
                context.stroke(path, with: .color(color), lineWidth: lineWidth)
            }
        }
    }
}
