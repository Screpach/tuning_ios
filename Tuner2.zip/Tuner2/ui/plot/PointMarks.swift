import SwiftUI

struct PointMark: Identifiable {
    let id = UUID()
    let position: CGPoint
    let settings: Settings
    // content: Composable
    
    struct Settings {
        var anchor: Anchor = .center
        var screenOffset: CGPoint = .zero
    }
}

struct PointMarks: View {
    let marks: [PointMark]
    let clipLabelsToWindow: Bool
    let sameSizeLabels: Bool
    let clipped: Bool
    let transformation: () -> Transformation
    
    var body: some View {
        if clipLabelsToWindow == clipped {
            ForEach(marks) { mark in
                let t = transformation()
                let screenPos = t.toScreen(mark.position)
                
                // For this port, we assume a Text label as content
                Text("•")
                    .position(
                        x: screenPos.x + mark.settings.screenOffset.x,
                        y: screenPos.y + mark.settings.screenOffset.y
                    )
            }
        }
    }
}
