import SwiftUI

// Internal helper for Hex initialization to avoid external helper files
fileprivate extension Color {
    init(hex: UInt, alpha: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xff) / 255,
            green: Double((hex >> 08) & 0xff) / 255,
            blue: Double((hex >> 00) & 0xff) / 255,
            opacity: alpha
        )
    }
}

// MARK: - Light Theme Colors
let md_theme_light_primary = Color(hex: 0xFF175DB2)
let md_theme_light_onPrimary = Color(hex: 0xFFFFFFFF)
let md_theme_light_primaryContainer = Color(hex: 0xFFD6E3FF)
let md_theme_light_onPrimaryContainer = Color(hex: 0xFF001B3E)
let md_theme_light_secondary = Color(hex: 0xFF285EA7)
let md_theme_light_onSecondary = Color(hex: 0xFFFFFFFF)
let md_theme_light_secondaryContainer = Color(hex: 0xFFD6E3FF)
let md_theme_light_onSecondaryContainer = Color(hex: 0xFF001B3D)
let md_theme_light_tertiary = Color(hex: 0xFF814791)
let md_theme_light_onTertiary = Color(hex: 0xFFFFFFFF)
let md_theme_light_tertiaryContainer = Color(hex: 0xFFFBD7FF)
let md_theme_light_onTertiaryContainer = Color(hex: 0xFF330044)
let md_theme_light_error = Color(hex: 0xFFBA1A1A)
let md_theme_light_errorContainer = Color(hex: 0xFFFFDAD6)
let md_theme_light_onError = Color(hex: 0xFFFFFFFF)
let md_theme_light_onErrorContainer = Color(hex: 0xFF410002)
let md_theme_light_background = Color(hex: 0xFFFDFBFF)
let md_theme_light_onBackground = Color(hex: 0xFF1A1B1E)
let md_theme_light_surface = Color(hex: 0xFFFDFBFF)
let md_theme_light_onSurface = Color(hex: 0xFF1A1B1E)
let md_theme_light_surfaceVariant = Color(hex: 0xFFE0E2EC)
let md_theme_light_onSurfaceVariant = Color(hex: 0xFF44474E)
let md_theme_light_outline = Color(hex: 0xFF74777F)
let md_theme_light_inverseOnSurface = Color(hex: 0xFFF1F0F4)
let md_theme_light_inverseSurface = Color(hex: 0xFF2F3033)
let md_theme_light_inversePrimary = Color(hex: 0xFFAAC7FF)
let md_theme_light_shadow = Color(hex: 0xFF000000)
let md_theme_light_surfaceTint = Color(hex: 0xFF175DB2)
let md_theme_light_outlineVariant = Color(hex: 0xFFC4C6D0)
let md_theme_light_scrim = Color(hex: 0xFF000000)

// MARK: - Dark Theme Colors
let md_theme_dark_primary = Color(hex: 0xFFAAC7FF)
let md_theme_dark_onPrimary = Color(hex: 0xFF002F64)
let md_theme_dark_primaryContainer = Color(hex: 0xFF00458D)
let md_theme_dark_onPrimaryContainer = Color(hex: 0xFFD6E3FF)
let md_theme_dark_secondary = Color(hex: 0xFFA9C7FF)
let md_theme_dark_onSecondary = Color(hex: 0xFF003063)
let md_theme_dark_secondaryContainer = Color(hex: 0xFF00468B)
let md_theme_dark_onSecondaryContainer = Color(hex: 0xFFD6E3FF)
let md_theme_dark_tertiary = Color(hex: 0xFFF0B0FF)
let md_theme_dark_onTertiary = Color(hex: 0xFF4E165F)
let md_theme_dark_tertiaryContainer = Color(hex: 0xFF672F78)
let md_theme_dark_onTertiaryContainer = Color(hex: 0xFFFBD7FF)
let md_theme_dark_error = Color(hex: 0xFFFFB4AB)
let md_theme_dark_errorContainer = Color(hex: 0xFF93000A)
let md_theme_dark_onError = Color(hex: 0xFF690005)
let md_theme_dark_onErrorContainer = Color(hex: 0xFFFFDAD6)
let md_theme_dark_background = Color(hex: 0xFF1A1B1E)
let md_theme_dark_onBackground = Color(hex: 0xFFE3E2E6)
let md_theme_dark_surface = Color(hex: 0xFF1A1B1E)
let md_theme_dark_onSurface = Color(hex: 0xFFE3E2E6)
let md_theme_dark_surfaceVariant = Color(hex: 0xFF44474E)
let md_theme_dark_onSurfaceVariant = Color(hex: 0xFFC4C6D0)
let md_theme_dark_outline = Color(hex: 0xFF8E9099)
let md_theme_dark_inverseOnSurface = Color(hex: 0xFF1A1B1E)
let md_theme_dark_inverseSurface = Color(hex: 0xFFE3E2E6)
let md_theme_dark_inversePrimary = Color(hex: 0xFF175DB2)
let md_theme_dark_shadow = Color(hex: 0xFF000000)
let md_theme_dark_surfaceTint = Color(hex: 0xFFAAC7FF)
let md_theme_dark_outlineVariant = Color(hex: 0xFF44474E)
let md_theme_dark_scrim = Color(hex: 0xFF000000)

// MARK: - Custom Tuner Colors
let seed = Color(hex: 0xFF175DB2)
let positive = Color(hex: 0xFF006E17)
let negative = Color(hex: 0xFFB22735)

let light_positive = Color(hex: 0xFF006E17)
let light_onpositive = Color(hex: 0xFFFFFFFF)
let light_positiveContainer = Color(hex: 0xFF99F990)
let light_onpositiveContainer = Color(hex: 0xFF002203)

let dark_positive = Color(hex: 0xFF7DDC77)
let dark_onpositive = Color(hex: 0xFF003907)
let dark_positiveContainer = Color(hex: 0xFF00530F)
let dark_onpositiveContainer = Color(hex: 0xFF99F990)

let light_negative = Color(hex: 0xFFB22735)
let light_onnegative = Color(hex: 0xFFFFFFFF)
let light_negativeContainer = Color(hex: 0xFFFFDAD9)
let light_onnegativeContainer = Color(hex: 0xFF410008)

let dark_negative = Color(hex: 0xFFFFB3B2)
let dark_onnegative = Color(hex: 0xFF680013)
let dark_negativeContainer = Color(hex: 0xFF900821)
let dark_onnegativeContainer = Color(hex: 0xFFFFDAD9)
