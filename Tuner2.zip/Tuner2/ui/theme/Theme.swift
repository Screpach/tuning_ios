import SwiftUI

// MARK: - Tuner Colors Model
struct TunerColors {
    var positive: Color = .clear
    var onPositive: Color = .clear
    var negative: Color = .clear
    var onNegative: Color = .clear
}

// MARK: - Predefined Color Sets
let OnLightTunerColors = TunerColors(
    positive: light_positive,
    onPositive: light_onpositive,
    negative: light_negative,
    onNegative: light_onnegative
)

let OnDarkTunerColors = TunerColors(
    positive: dark_positive,
    onPositive: dark_onpositive,
    negative: dark_negative,
    onNegative: dark_onnegative
)

// MARK: - Environment Keys
struct TunerColorsKey: EnvironmentKey {
    static let defaultValue = TunerColors()
}

struct TunerTypographyKey: EnvironmentKey {
    static let defaultValue = TunerTypography()
}

extension EnvironmentValues {
    var tunerColors: TunerColors {
        get { self[TunerColorsKey.self] }
        set { self[TunerColorsKey.self] = newValue }
    }
    
    var tunerTypography: TunerTypography {
        get { self[TunerTypographyKey.self] }
        set { self[TunerTypographyKey.self] = newValue }
    }
}

// MARK: - Tuner Theme
struct TunerTheme<Content: View>: View {
    @Environment(\.colorScheme) var systemColorScheme
    
    var darkTheme: Bool?
    var dynamicColor: Bool = true // iOS doesn't strictly support Android's 'Dynamic Color' wallpaper engine in the same way, but keeping API signature.
    var blackNightMode: Bool = false
    var content: Content
    
    init(
        darkTheme: Bool? = nil,
        dynamicColor: Bool = true,
        blackNightMode: Bool = false,
        @ViewBuilder content: () -> Content
    ) {
        self.darkTheme = darkTheme
        self.dynamicColor = dynamicColor
        self.blackNightMode = blackNightMode
        self.content = content()
    }
    
    var body: some View {
        let isDark = darkTheme ?? (systemColorScheme == .dark)
        
        let tunerColors = isDark ? OnDarkTunerColors : OnLightTunerColors
        
        // Note: In strict SwiftUI, we usually rely on the Asset Catalog for light/dark switching.
        // However, to respect the provided Kotlin file's logic of explicit color palettes:
        
        let primaryColor = isDark ? md_theme_dark_primary : md_theme_light_primary
        let backgroundColor = (isDark && blackNightMode) ? Color.black : (isDark ? md_theme_dark_background : md_theme_light_background)
        let surfaceColor = (isDark && blackNightMode) ? Color.black : (isDark ? md_theme_dark_surface : md_theme_light_surface)
        
        // We use a ZStack to apply the background color to the whole content
        ZStack {
            backgroundColor.ignoresSafeArea()
            
            content
        }
        .environment(\.tunerColors, tunerColors)
        .environment(\.tunerTypography, tunerTypography)
        .tint(primaryColor) // Sets the global tint color (like Primary in Material)
        .foregroundColor(isDark ? md_theme_dark_onBackground : md_theme_light_onBackground)
        .preferredColorScheme(isDark ? .dark : .light)
    }
}
