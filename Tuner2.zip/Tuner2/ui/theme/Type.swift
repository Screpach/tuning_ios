import SwiftUI

// MARK: - Tuner Typography Definition
struct TunerTypography {
    var plotSmall: Font = .system(size: 14)
    var plotMedium: Font = .system(size: 16)
    var plotLarge: Font = .system(size: 22)
}

let tunerTypography = TunerTypography()

// MARK: - App Typography
// Mimicking Material3 Typography structure for the main app styles
struct AppTypography {
    let bodyLarge: Font
    // Add other styles as they are uncommented/added in the future
}

// Set of Material typography styles to start with
let Typography = AppTypography(
    bodyLarge: .system(size: 16, weight: .regular) // LineHeight and letterSpacing are typically applied as modifiers in SwiftUI
)
