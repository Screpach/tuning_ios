import SwiftUI

/// Horizontal picker for notes.
/// Equivalent to `NoteSelector.kt`.
struct NoteSelector: View {
    
    @Binding var selectedIndex: Int
    let notes: [MusicalNote]
    let notePrintOptions: NotePrintOptions
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            ScrollViewReader { proxy in
                HStack(spacing: 8) {
                    ForEach(Array(notes.enumerated()), id: \.offset) { index, note in
                        NoteSelectorItem(
                            note: note,
                            isSelected: index == selectedIndex,
                            notePrintOptions: notePrintOptions,
                            onClick: {
                                selectedIndex = index
                                withAnimation {
                                    proxy.scrollTo(index, anchor: .center)
                                }
                            }
                        )
                        .id(index)
                    }
                }
                .padding(.horizontal)
                .onAppear {
                    // Initial scroll
                    proxy.scrollTo(selectedIndex, anchor: .center)
                }
            }
        }
        .frame(height: 50)
    }
}

struct NoteSelectorItem: View {
    let note: MusicalNote
    let isSelected: Bool
    let notePrintOptions: NotePrintOptions
    let onClick: () -> Void
    
    var body: some View {
        Button(action: onClick) {
            Note(
                musicalNote: note,
                withOctave: false, // Selector usually just shows chroma
                notePrintOptions: notePrintOptions,
                color: isSelected ? .white : .primary,
                fontWeight: isSelected ? .bold : .regular
            )
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(isSelected ? MaterialTheme.colorScheme.primary : MaterialTheme.colorScheme.surface)
            .clipShape(RoundedRectangle(cornerRadius: 8))
        }
    }
}
