import SwiftUI

/// Displays the detected note history.
/// Equivalent to `NoteDetector.kt`.
struct NoteDetector: View {
    
    @ObservedObject var state: NoteDetectorState
    let musicalScale: MusicalScale2
    let notePrintOptions: NotePrintOptions = NotePrintOptions.flatSharp // Default
    
    var body: some View {
        HStack(alignment: .center, spacing: 16) {
            // Iterate recent notes
            ForEach(state.notes) { item in
                let isCurrent = (item.id == state.currentNoteId)
                
                Note(
                    musicalNote: item.note,
                    withOctave: true,
                    notePrintOptions: notePrintOptions,
                    color: isCurrent ? .primary : .secondary.opacity(0.5),
                    font: isCurrent ? .largeTitle : .title3,
                    fontWeight: isCurrent ? .bold : .regular
                )
                .scaleEffect(isCurrent ? 1.2 : 1.0)
                .animation(.spring(response: 0.3), value: isCurrent)
            }
        }
        .frame(height: 100)
    }
}

// MARK: - State

class NoteDetectorState: ObservableObject, Identifiable {
    struct NoteItem: Identifiable {
        let id = UUID()
        let note: MusicalNote
    }
    
    @Published var notes: [NoteItem] = []
    @Published var currentNoteId: UUID?
    
    func hitNote(_ note: MusicalNote) {
        // Logic to add note to history, limit size, update current
        let newItem = NoteItem(note: note)
        
        // Simple queue logic
        var newNotes = notes
        newNotes.append(newItem)
        if newNotes.count > 5 {
            newNotes.removeFirst()
        }
        
        notes = newNotes
        currentNoteId = newItem.id
    }
}
