import SwiftUI

/// Visual arrow indicating a fifth interval and its correction.
/// Equivalent to `FifthJumpOverArrow.kt`.
struct FifthJumpOverArrow: View {
    
    let fifthModification: FifthModification?
    var color: Color = .secondary
    
    var body: some View {
        VStack(spacing: 2) {
            // Label
            if let mod = fifthModification {
                Text(formatModification(mod))
                    .font(.caption2)
                    .foregroundStyle(color)
            } else {
                Text("?")
                    .font(.caption2)
                    .foregroundStyle(color)
            }
            
            // Arrow Graphic
            // Since we don't have the SVG assets, we draw a path using Canvas
            Canvas { context, size in
                let w = size.width
                let h = size.height
                let midY = h / 2
                
                var path = Path()
                // Simple arc or straight line with arrow
                path.move(to: CGPoint(x: 0, y: midY))
                path.addLine(to: CGPoint(x: w, y: midY))
                
                // Arrowhead
                path.move(to: CGPoint(x: w - 5, y: midY - 3))
                path.addLine(to: CGPoint(x: w, y: midY))
                path.addLine(to: CGPoint(x: w - 5, y: midY + 3))
                
                context.stroke(path, with: .color(color), lineWidth: 1.5)
            }
            .frame(height: 12)
            .frame(minWidth: 40)
        }
    }
    
    private func formatModification(_ mod: FifthModification) -> String {
        // Simplified formatting for Phase 1
        // Real implementation would check pythagorean/syntonic commas
        if mod.pythagoreanComma.numerator != 0 {
            return "\(mod.pythagoreanComma.numerator)/\(mod.pythagoreanComma.denominator) P"
        }
        return ""
    }
}
