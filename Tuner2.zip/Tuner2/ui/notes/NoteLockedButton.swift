import SwiftUI

/// Button displaying a note with a "locked" icon and a clear action.
/// Equivalent to `NoteLockedButton.kt`.
struct NoteLockedButton: View {
    
    let note: MusicalNote
    let notePrintOptions: NotePrintOptions
    var onClick: () -> Void
    
    var body: some View {
        Button(action: onClick) {
            HStack {
                Image(systemName: "lock.fill")
                    .imageScale(.small)
                
                Note(
                    musicalNote: note,
                    withOctave: true,
                    notePrintOptions: notePrintOptions,
                    font: .body,
                    fontWeight: .bold
                )
                
                Spacer().frame(width: 8)
                
                Image(systemName: "xmark")
                    .imageScale(.small)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(MaterialTheme.colorScheme.surface)
            .clipShape(Capsule())
            .overlay(
                Capsule().strokeBorder(MaterialTheme.colorScheme.primary, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}
