import SwiftUI

/// Full editor for complex note configuration.
/// Equivalent to `NoteEditor.kt`.
struct NoteEditor: View {
    
    let base: BaseNote
    let modifier: NoteModifier
    let onNoteChange: (BaseNote, NoteModifier) -> Void
    let notePrintOptions: NotePrintOptions
    
    // In Kotlin this had dropdowns. We use Pickers in Swift.
    
    var body: some View {
        Form {
            Section("Base Note") {
                Picker("Base", selection: Binding(
                    get: { base },
                    set: { onNoteChange($0, modifier) }
                )) {
                    ForEach(BaseNote.allCases, id: \.self) { note in
                        Text(note.rawValue).tag(note)
                    }
                }
            }
            
            Section("Modifier") {
                Picker("Modifier", selection: Binding(
                    get: { modifier },
                    set: { onNoteChange(base, $0) }
                )) {
                    ForEach(NoteModifier.allCases, id: \.self) { mod in
                        Text(mod.rawValue).tag(mod)
                    }
                }
            }
        }
    }
}
