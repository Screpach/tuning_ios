import SwiftUI

/// Displays a formatted musical note (e.g. A#4).
/// Equivalent to `Note.kt`.
struct Note: View {
    
    let musicalNote: MusicalNote
    let withOctave: Bool
    let notePrintOptions: NotePrintOptions
    var color: Color = .primary
    var font: Font = .body
    var fontWeight: Font.Weight = .regular
    
    var body: some View {
        // Construct the text components
        // In a real app, notePrintOptions determines how modifiers look (Symbol vs Text)
        // For Phase 1, we use standard text representation.
        
        HStack(alignment: .lastTextBaseline, spacing: 0) {
            Text(musicalNote.base.rawValue)
                .font(font)
                .fontWeight(fontWeight)
                .foregroundStyle(color)
            
            // Modifier (Superscript/Subscript logic)
            if musicalNote.modifier != .None {
                Text(modifierString(musicalNote.modifier))
                    .font(font) // Usually smaller?
                    .fontWeight(fontWeight)
                    .baselineOffset(fontPoint(font) * 0.3) // Superscript effect
                    .font(.system(size: fontPoint(font) * 0.7)) // Smaller size
                    .foregroundStyle(color)
            }
            
            // Octave (Subscript logic)
            if withOctave {
                Text("\(musicalNote.octave)")
                    .font(font)
                    .fontWeight(fontWeight)
                    .baselineOffset(fontPoint(font) * -0.2) // Subscript effect
                    .font(.system(size: fontPoint(font) * 0.7))
                    .foregroundStyle(color)
            }
        }
    }
    
    // Helper to estimate font size for offsets
    private func fontPoint(_ font: Font) -> CGFloat {
        // Rough estimation since SwiftUI Font doesn't expose point size easily
        // In a real app, pass explicit size or use ScaledMetric
        return 17.0
    }
    
    private func modifierString(_ mod: NoteModifier) -> String {
        // Map enum to symbol
        switch mod {
        case .Sharp, .SharpUp, .SharpDown: return "♯"
        case .Flat, .FlatUp, .FlatDown: return "♭"
        case .SharpSharp: return "𝄪" // Double sharp
        case .FlatFlat: return "𝄫" // Double flat
        // Add full mapping for microtonal arrows if needed
        default: return mod.rawValue
        }
    }
}
