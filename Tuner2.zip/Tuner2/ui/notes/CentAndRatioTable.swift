import SwiftUI

/// Table showing cents and ratios for a temperament.
/// Equivalent to `CentAndRatioTable.kt`.
struct CentAndRatioTable: View {
    
    let temperament: Temperament3
    let rootNote: MusicalNote?
    let notePrintOptions: NotePrintOptions
    
    var body: some View {
        let cents = temperament.cents()
        let ratios = temperament.rationalNumbers()
        
        // We need note names.
        // Note: noteNames() returns `NoteNames2`.
        let noteNamesObj = temperament.noteNames(rootNote: rootNote)
        
        ScrollView(.horizontal, showsIndicators: true) {
            HStack(spacing: 0) {
                // Iterate through notes
                // noteNamesObj.notes doesn't include the octave repetition usually,
                // but cents/ratios array size is N+1.
                
                ForEach(0..<cents.count, id: \.self) { i in
                    VStack(spacing: 8) {
                        // 1. Note Name
                        if i < noteNamesObj.notes.count {
                            Note(
                                musicalNote: noteNamesObj.notes[i],
                                withOctave: false,
                                notePrintOptions: notePrintOptions
                            )
                        } else if i == noteNamesObj.notes.count {
                            // Octave note (First note + octave shift)
                            // Simplified for display
                            Note(
                                musicalNote: noteNamesObj.notes[0], // Logic should handle octave shift
                                withOctave: false,
                                notePrintOptions: notePrintOptions
                            )
                        }
                        
                        Divider()
                        
                        // 2. Cents
                        Text(String(format: "%.1f", cents[i]))
                            .font(.caption)
                            .monospacedDigit()
                        
                        // 3. Ratio (if available)
                        if let ratioList = ratios, i < ratioList.count, let ratio = ratioList[i] {
                            Fraction(ratio.numerator, ratio.denominator)
                        } else {
                            // Placeholder to align height
                            Text("-").font(.caption).hidden()
                        }
                    }
                    .padding(.horizontal, 12)
                    
                    // Vertical Separator
                    if i < cents.count - 1 {
                        Divider()
                    }
                }
            }
            .padding()
        }
        .background(MaterialTheme.colorScheme.surface)
        .cornerRadius(8)
    }
}
