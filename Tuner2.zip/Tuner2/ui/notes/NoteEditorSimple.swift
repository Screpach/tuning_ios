import SwiftUI

/// Simple editor for modifying a note's properties.
/// Equivalent to `NoteEditorSimple.kt`.
struct NoteEditorSimple: View {
    
    let base: BaseNote
    let modifier: NoteModifier
    let octaveOffset: Int
    let onNoteChange: (BaseNote, NoteModifier, Int) -> Void
    let notePrintOptions: NotePrintOptions
    
    var body: some View {
        VStack(spacing: 16) {
            // Base Note Picker (Segmented or Wheel)
            // Ideally a custom grid or wheel. Using Segmented for Phase 1.
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(BaseNote.allCases.filter { $0 != .None }, id: \.self) { b in
                        Button(b.rawValue) {
                            onNoteChange(b, modifier, octaveOffset)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(b == base ? .accentColor : .gray)
                    }
                }
            }
            
            // Modifier Picker
            // Simplified list: Flat, Natural, Sharp
            HStack {
                Button("♭") { onNoteChange(base, .Flat, octaveOffset) }
                    .buttonStyle(.bordered)
                    .tint(modifier == .Flat ? .accentColor : .primary)
                
                Button("♮") { onNoteChange(base, .None, octaveOffset) }
                    .buttonStyle(.bordered)
                    .tint(modifier == .None ? .accentColor : .primary)
                
                Button("♯") { onNoteChange(base, .Sharp, octaveOffset) }
                    .buttonStyle(.bordered)
                    .tint(modifier == .Sharp ? .accentColor : .primary)
            }
            
            // Octave Offset
            Stepper("Octave Offset: \(octaveOffset)", value: Binding(
                get: { octaveOffset },
                set: { onNoteChange(base, modifier, $0) }
            ))
        }
        .padding()
    }
}
