import SwiftUI

/// Displays a rational number as a vertical fraction.
/// Equivalent to `Fraction.kt`.
struct Fraction: View {
    
    let numerator: Int
    let denominator: Int
    let color: Color
    
    init(_ numerator: Int, _ denominator: Int, color: Color = .primary) {
        self.numerator = numerator
        self.denominator = denominator
        self.color = color
    }
    
    var body: some View {
        VStack(spacing: 0) {
            Text("\(numerator)")
                .font(.caption)
                .foregroundStyle(color)
            
            Rectangle()
                .fill(color)
                .frame(height: 1)
                .padding(.horizontal, 2)
            
            Text("\(denominator)")
                .font(.caption)
                .foregroundStyle(color)
        }
        .fixedSize() // Prevent expansion
    }
}
