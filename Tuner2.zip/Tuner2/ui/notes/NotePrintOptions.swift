import Foundation

/// Options for displaying octaves.
/// Equivalent to `OctaveNotation` in `NotePrintOptions.kt`.
enum OctaveNotation: Int, Codable, Sendable {
    case scientific = 0 // A4
    case helmholtz = 1  // a'
    case helmholtzNumbered = 2 // a¹
}

/// Options for naming notes (C, D, E vs Do, Re, Mi).
/// Equivalent to `NotationType` in `NoteNotationType.kt`.
enum NotationType: Int, Codable, Sendable {
    case standard = 0
    case international = 1
    case solfege = 2
    case german = 3
    case indian = 4
    case vietnamese = 5
    // Add full list if needed
    
    // Stub for resource lookup
    func localizedName() -> String {
        switch self {
        case .standard: return "Standard"
        case .international: return "International"
        case .solfege: return "Solfege"
        default: return "Standard"
        }
    }
}

/// Configuration for note printing.
/// Equivalent to `NotePrintOptions2`.
struct NotePrintOptions: Codable, Equatable, Sendable {
    
    var enharmonicVariant: Int = 0 // 0 = default, 1 = alternative
    var octaveNotation: OctaveNotation = .scientific
    var notationType: NotationType = .standard
    
    // Predefined configurations
    static let flatSharp = NotePrintOptions(enharmonicVariant: 0, octaveNotation: .scientific, notationType: .standard)
    static let solfege = NotePrintOptions(enharmonicVariant: 0, octaveNotation: .scientific, notationType: .solfege)
    static let fixedDo = NotePrintOptions(enharmonicVariant: 0, octaveNotation: .scientific, notationType: .solfege) // Approximation
}
