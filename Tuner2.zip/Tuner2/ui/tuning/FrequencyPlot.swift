import SwiftUI
import Charts

// MARK: - Data Models (Internal Stubs to match Kotlin logic)
struct FrequencyPoint: Identifiable {
    let id = UUID()
    let frequency: Float
    let amplitude: Float
}

struct FrequencyPlotData {
    let points: [FrequencyPoint]
}

// MARK: - Frequency Plot
struct FrequencyPlot: View {
    let frequencyPlotData: FrequencyPlotData
    // In Swift, we typically pass the calculated frequency values rather than the full Scale object
    // to keep the View pure, but we will accept a generic scale object or closure here.
    let targetFrequency: Float
    
    var modifier: Modifier = Modifier() // Placeholder for Compose modifier equivalent
    
    // Line properties
    var lineWidth: CGFloat = 2.0
    var lineColor: Color = .primary
    
    // Current frequency
    var currentFrequency: Float? = nil
    var frequencyMarkColor: Color = .secondary
    
    // Harmonics
    var harmonicFrequencies: [Float]? = nil
    var harmonicLineColor: Color = .secondary
    
    // Viewport
    @State private var zoomDomain: ClosedRange<Float>?
    
    var body: some View {
        Chart {
            // 1. Plot the Main Frequency Line
            ForEach(frequencyPlotData.points) { point in
                LineMark(
                    x: .value("Frequency", point.frequency),
                    y: .value("Amplitude", point.amplitude)
                )
                .lineStyle(StrokeStyle(lineWidth: lineWidth))
                .foregroundStyle(lineColor)
                .interpolationMethod(.catmullRom) // Smooths the line
            }
            
            // 2. Harmonic Vertical Lines
            if let harmonics = harmonicFrequencies {
                ForEach(harmonics, id: \.self) { harmonic in
                    RuleMark(
                        x: .value("Harmonic", harmonic)
                    )
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [5, 5]))
                    .foregroundStyle(harmonicLineColor)
                }
            }
            
            // 3. Current Detected Frequency Mark
            if let current = currentFrequency {
                RuleMark(
                    x: .value("Current", current)
                )
                .lineStyle(StrokeStyle(lineWidth: 1))
                .foregroundStyle(frequencyMarkColor)
                .annotation(position: .top, alignment: .center) {
                    Text("\(current, specifier: "%.1f") Hz")
                        .font(.caption)
                        .foregroundColor(frequencyMarkColor)
                        .padding(2)
                        .background(.regularMaterial)
                        .cornerRadius(4)
                }
            }
        }
        .chartXScale(domain: zoomDomain ?? 0...(targetFrequency * 3.5))
        .chartYAxis(.hidden) // Generally hidden in tuner apps, or customize
        .chartXAxis {
            AxisMarks(values: .automatic) { value in
                if let freq = value.as(Double.self) {
                    AxisGridLine()
                    AxisTick()
                    AxisValueLabel("\(Int(freq)) Hz")
                }
            }
        }
        // Enable Zooming/Panning
        .chartScrollableAxes(.horizontal)
        .chartXSelection(range: $zoomDomain)
        .padding()
    }
}

// MARK: - Preview
struct FrequencyPlot_Previews: PreviewProvider {
    static var previews: some View {
        let points = (0..<20).map { i in
            FrequencyPoint(frequency: Float(i) * 200, amplitude: Float.random(in: 0...10))
        }
        
        FrequencyPlot(
            frequencyPlotData: FrequencyPlotData(points: points),
            targetFrequency: 440.0,
            currentFrequency: 1200.0,
            harmonicFrequencies: [300, 510, 800],
            harmonicLineColor: .red
        )
        .frame(height: 200)
    }
}

// Helper types to mimic Compose Modifier behavior if needed
struct Modifier {
    // Placeholder
}
