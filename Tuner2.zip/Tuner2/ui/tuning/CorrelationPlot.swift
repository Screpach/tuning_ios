import SwiftUI
import Charts

// MARK: - Data Models
struct CorrelationPoint: Identifiable {
    let id = UUID()
    let timeShift: Float
    let correlation: Float
}

struct CorrelationPlotData {
    let points: [CorrelationPoint]
}

// MARK: - Correlation Plot
struct CorrelationPlot: View {
    let correlationPlotData: CorrelationPlotData
    let correlationPlotDataYZeroPosition: Float
    
    // In Kotlin, targetNote/MusicalScale determined the viewport.
    // Here we pass the calculated bounds or target period.
    let targetPeriod: Float
    
    var modifier: Modifier = Modifier()
    
    var lineWidth: CGFloat = 2.0
    var lineColor: Color = .primary
    
    // Current Frequency (converted to time shift 1/f internally)
    var currentFrequency: Float? = nil
    var frequencyMarkColor: Color = .secondary
    
    var body: some View {
        Chart {
            // 1. Zero Line
            RuleMark(y: .value("Zero", correlationPlotDataYZeroPosition))
                .lineStyle(StrokeStyle(lineWidth: 1))
                .foregroundStyle(Color.secondary.opacity(0.5))
            
            // 2. Correlation Curve
            ForEach(correlationPlotData.points) { point in
                LineMark(
                    x: .value("Time Shift", point.timeShift),
                    y: .value("Correlation", point.correlation)
                )
                .lineStyle(StrokeStyle(lineWidth: lineWidth))
                .foregroundStyle(lineColor)
                .interpolationMethod(.monotone)
            }
            
            // 3. Current Frequency Mark (Converted to Period)
            if let currentFreq = currentFrequency, currentFreq > 0 {
                let period = 1.0 / currentFreq
                RuleMark(
                    x: .value("Current Period", period)
                )
                .lineStyle(StrokeStyle(lineWidth: 1))
                .foregroundStyle(frequencyMarkColor)
                .annotation(position: .top) {
                    Text("\(currentFreq, specifier: "%.1f") Hz")
                        .font(.caption)
                        .foregroundColor(frequencyMarkColor)
                        .padding(2)
                        .background(.regularMaterial)
                        .cornerRadius(4)
                }
            }
        }
        // X-Axis: Time Shift, but we often want to read it as Frequency (1/x)
        // Swift Charts doesn't easily support non-linear custom labels on linear axes,
        // so we stick to Time Shift for the axis, or standard formatting.
        .chartXAxis {
            AxisMarks { value in
                AxisGridLine()
                AxisTick()
                if let t = value.as(Double.self), t > 0 {
                    // Option: Display Frequency (Hz) on the label instead of time
                    let freq = 1.0 / t
                    if freq < 10000 {
                        AxisValueLabel("\(Int(freq)) Hz")
                    }
                }
            }
        }
        // Setting the visible domain based on target note logic
        .chartXScale(domain: 0 ... (targetPeriod * 2.5))
        .chartScrollableAxes(.horizontal)
        .padding()
    }
}

// MARK: - Preview
struct CorrelationPlot_Previews: PreviewProvider {
    static var previews: some View {
        let points = (0..<20).map { i in
            CorrelationPoint(timeShift: Float(i) * 0.0004, correlation: Float.random(in: -3...10))
        }
        
        CorrelationPlot(
            correlationPlotData: CorrelationPlotData(points: points),
            correlationPlotDataYZeroPosition: 0,
            targetPeriod: 1.0 / 440.0, // A4
            currentFrequency: 500.0
        )
        .frame(height: 200)
    }
}

struct Modifier { }
