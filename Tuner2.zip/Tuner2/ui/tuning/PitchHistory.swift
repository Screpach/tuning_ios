import SwiftUI
import Charts

// MARK: - Logic & Models
enum TuningState {
    case unknown
    case inTune
    case tooLow
    case tooHigh
}

struct PitchPoint: Identifiable {
    let id = UUID()
    let index: Int
    let frequency: Float
}

// Helper to calculate cents
private func ratioToCents(ratio: Float) -> Float {
    return 1200 * log2(ratio)
}

private func centsToRatio(cents: Float) -> Float {
    return pow(2.0, cents / 1200.0)
}

struct PitchHistoryState {
    var history: [PitchPoint] = []
    var capacity: Int
    private var counter: Int = 0
    
    mutating func addFrequency(_ value: Float) {
        if history.count >= capacity {
            history.removeFirst()
        }
        history.append(PitchPoint(index: counter, frequency: value))
        counter += 1
    }
    
    mutating func resize(newCapacity: Int) {
        self.capacity = newCapacity
        if history.count > newCapacity {
            history = Array(history.suffix(newCapacity))
        }
    }
    
    var lastPoint: PitchPoint? {
        return history.last
    }
}

// MARK: - Pitch History View
struct PitchHistory: View {
    let state: PitchHistoryState
    // Domain objects (Mocked interface)
    let targetNoteName: String
    let targetFrequency: Float
    
    var tuningState: TuningState = .unknown
    
    // UI Properties
    var lineWidth: CGFloat = 2.0
    var pointSize: CGFloat = 10.0
    
    // Colors
    var colorInTune: Color = .green
    var colorOutOfTune: Color = .red
    var colorInactive: Color = .gray
    
    var toleranceInCents: Int = 5
    
    private var activeColor: Color {
        switch tuningState {
        case .inTune: return colorInTune
        case .tooLow, .tooHigh: return colorOutOfTune
        case .unknown: return colorInactive
        }
    }
    
    var body: some View {
        GeometryReader { geometry in
            let toleranceRatio = centsToRatio(cents: Float(toleranceInCents))
            let upperFreq = targetFrequency * toleranceRatio
            let lowerFreq = targetFrequency / toleranceRatio
            
            Chart {
                // 1. Tolerance Band (Optional: visual indication of in-tune zone)
                RectangleMark(
                    yStart: .value("Lower", lowerFreq),
                    yEnd: .value("Upper", upperFreq)
                )
                .foregroundStyle(Color.secondary.opacity(0.1))
                
                // 2. Target Note Line
                RuleMark(y: .value("Target", targetFrequency))
                    .lineStyle(StrokeStyle(lineWidth: 2))
                    .foregroundStyle(activeColor)
                    .annotation(position: .leading) {
                        Text(targetNoteName)
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(activeColor)
                            .padding(4)
                            .background(Color(UIColor.systemBackground).opacity(0.8))
                    }
                
                // 3. History Line
                ForEach(state.history) { point in
                    LineMark(
                        x: .value("Index", point.index),
                        y: .value("Frequency", point.frequency)
                    )
                    .lineStyle(StrokeStyle(lineWidth: lineWidth))
                    .foregroundStyle(tuningState == .unknown ? colorInactive : .primary)
                    .interpolationMethod(.catmullRom)
                }
                
                // 4. Current Point Head
                if let last = state.lastPoint {
                    PointMark(
                        x: .value("Index", last.index),
                        y: .value("Frequency", last.frequency)
                    )
                    .symbolSize(pointSize * 3) // Scale for visibility
                    .foregroundStyle(activeColor)
                    // Custom Symbols for Up/Down arrows
                    .symbol {
                        ZStack {
                            if tuningState == .tooLow {
                                Image(systemName: "triangle.fill")
                                    .foregroundColor(activeColor)
                            } else if tuningState == .tooHigh {
                                Image(systemName: "triangle.fill")
                                    .rotationEffect(.degrees(180))
                                    .foregroundColor(activeColor)
                            } else {
                                Circle()
                                    .fill(activeColor)
                            }
                        }
                        .frame(width: pointSize, height: pointSize)
                    }
                    .annotation(position: tuningState == .tooHigh ? .bottom : .top) {
                        if tuningState != .inTune && tuningState != .unknown {
                            let centDiff = Int(ratioToCents(ratio: last.frequency / targetFrequency))
                            Text("\(centDiff > 0 ? "+" : "")\(centDiff) ¢")
                                .font(.caption2)
                                .foregroundColor(activeColor)
                        }
                    }
                }
            }
            .chartYScale(domain: .automatic(includesZero: false))
            .chartXAxis(.hidden) // Hide time indices for cleaner look
            .chartYAxis {
                AxisMarks(values: .automatic) { value in
                    AxisGridLine()
                    AxisTick()
                    // In a real app, mapping Freq -> Note Name happens here
                    if let f = value.as(Double.self) {
                        AxisValueLabel("\(Int(f))")
                    }
                }
            }
            .padding()
        }
    }
}

// MARK: - Preview
struct PitchHistory_Previews: PreviewProvider {
    static var previews: some View {
        var state = PitchHistoryState(capacity: 20)
        // Simulate some data
        let freqs: [Float] = [440, 444, 430, 435, 439, 448, 450, 435, 445]
        for f in freqs {
            state.addFrequency(f)
        }
        
        return PitchHistory(
            state: state,
            targetNoteName: "A4",
            targetFrequency: 440.0,
            tuningState: .tooHigh,
            toleranceInCents: 10
        )
        .frame(height: 300)
    }
}
