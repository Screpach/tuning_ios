import SwiftUI

/// Icon for centering the instrument view.
/// Equivalent to `ScrollCenterIcon.kt`.
struct ScrollCenterIcon: View {
    var body: some View {
        ZStack {
            Image(systemName: "arrow.up.and.down") // Placeholder for arrows
                .imageScale(.small)
                .offset(x: -8)
            Image(systemName: "music.note.list") // Placeholder for string list
                .imageScale(.large)
        }
    }
}
