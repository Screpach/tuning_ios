import SwiftUI

/// Options for importing data.
enum ImportMode {
    case replace, ignoreDuplicates, renameDuplicates
}

/// Dialog to confirm instrument import strategy.
/// Equivalent to `ImportInstrumentsDialog.kt`.
struct ImportInstrumentsDialog: View {
    
    let instrumentsCount: Int
    var onImport: (ImportMode) -> Void
    var onDismiss: () -> Void
    
    @State private var selectedMode: ImportMode = .ignoreDuplicates
    
    var body: some View {
        VStack(spacing: 20) {
            Text(String(format: String(localized: "load_instruments_title", defaultValue: "Import %d Instruments?"), instrumentsCount))
                .font(.headline)
            
            VStack(alignment: .leading, spacing: 10) {
                RadioButton(
                    text: String(localized: "import_replace", defaultValue: "Replace existing"),
                    isSelected: selectedMode == .replace,
                    action: { selectedMode = .replace }
                )
                RadioButton(
                    text: String(localized: "import_ignore", defaultValue: "Ignore duplicates"),
                    isSelected: selectedMode == .ignoreDuplicates,
                    action: { selectedMode = .ignoreDuplicates }
                )
                RadioButton(
                    text: String(localized: "import_rename", defaultValue: "Rename duplicates"),
                    isSelected: selectedMode == .renameDuplicates,
                    action: { selectedMode = .renameDuplicates }
                )
            }
            
            HStack {
                Button(String(localized: "abort", defaultValue: "Cancel"), role: .cancel, action: onDismiss)
                Spacer()
                Button(String(localized: "ok", defaultValue: "Import"), action: { onImport(selectedMode) })
                    .buttonStyle(.borderedProminent)
            }
        }
        .padding()
    }
}

// Helper Radio Button
struct RadioButton: View {
    let text: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: isSelected ? "largecircle.fill.circle" : "circle")
                    .foregroundStyle(isSelected ? Color.accentColor : .secondary)
                Text(text)
                    .foregroundStyle(.primary)
            }
        }
    }
}
