import SwiftUI

/// Dialog for picking an instrument icon.
/// Equivalent to `InstrumentIconPicker.kt`.
struct InstrumentIconPicker: View {
    
    var onIconSelected: (InstrumentIcon) -> Void
    var onDismiss: () -> Void
    
    private let icons = InstrumentIcon.allCases
    
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 60))]) {
                    ForEach(icons, id: \.self) { icon in
                        Button(action: { onIconSelected(icon) }) {
                            VStack {
                                icon.image
                                    .resizable()
                                    .renderingMode(.template)
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 40, height: 40)
                                    .foregroundStyle(MaterialTheme.colorScheme.primary)
                                
                                Text(icon.rawValue)
                                    .font(.caption2)
                                    .lineLimit(1)
                            }
                            .padding()
                        }
                    }
                }
                .padding()
            }
            .navigationTitle(String(localized: "pick_icon", defaultValue: "Pick Icon"))
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(String(localized: "abort", defaultValue: "Cancel"), action: onDismiss)
                }
            }
        }
    }
}
