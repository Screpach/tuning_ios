import SwiftUI

/// A button displaying an instrument icon and name.
/// Equivalent to `InstrumentButton.kt`.
struct InstrumentButton: View {
    
    let icon: InstrumentIcon
    let name: String
    let outlineColor: Color?
    let errorMessage: String?
    var onClick: (() -> Void)? = nil
    
    var body: some View {
        Button(action: { onClick?() }) {
            HStack {
                icon.image
                    .resizable()
                    .renderingMode(.template)
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 24, height: 24)
                    .foregroundStyle(MaterialTheme.colorScheme.primary)
                
                Spacer().frame(width: 8)
                
                Text(name)
                    .font(.body)
                    .foregroundStyle(MaterialTheme.colorScheme.onSurface)
                    .lineLimit(1)
                
                if let error = errorMessage {
                    Spacer().frame(width: 8)
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundStyle(MaterialTheme.colorScheme.error)
                }
            }
            .padding(12)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(MaterialTheme.colorScheme.surface)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(outlineColor ?? Color.clear, lineWidth: 2)
            )
        }
        .buttonStyle(.plain)
    }
}

// Helper stub for MaterialTheme access
struct MaterialTheme {
    struct ColorScheme {
        static let primary = Color.blue
        static let onSurface = Color.primary
        static let surface = Color(UIColor.secondarySystemBackground)
        static let error = Color.red
    }
    static let colorScheme = ColorScheme()
}
