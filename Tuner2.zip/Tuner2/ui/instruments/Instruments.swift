import SwiftUI

/// Screen for managing instruments.
/// Equivalent to `Instruments.kt`.
struct Instruments: View {
    
    @ObservedObject var viewModel: InstrumentViewModel
    
    var onInstrumentClicked: (Instrument) -> Void
    var onEditIconClicked: (Instrument) -> Void
    var onNewInstrumentClicked: () -> Void
    
    // Import/Export logic usually handled by ViewModel or parent, here we trigger callbacks
    var onImportClicked: (() -> Void)? = nil
    var onExportClicked: (() -> Void)? = nil
    
    var body: some View {
        VStack {
            EditableList(
                state: viewModel.listData,
                onActivateItemClicked: onInstrumentClicked,
                onEditItemClicked: onEditIconClicked,
                onDeleteItemClicked: { viewModel.deleteCustomInstrument($0) }
            ) { instrument, info in
                HStack {
                    instrument.icon.image
                        .resizable()
                        .renderingMode(.template)
                        .frame(width: 32, height: 32)
                        .foregroundStyle(info.isSelected ? MaterialTheme.colorScheme.primary : .secondary)
                    
                    Text(instrument.getNameString())
                        .foregroundStyle(info.isSelected ? MaterialTheme.colorScheme.primary : .primary)
                }
                .padding(.vertical, 4)
            }
        }
        .navigationTitle(String(localized: "instruments", defaultValue: "Instruments"))
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                EditableListOverflowMenu(
                    onExportClicked: { onExportClicked?() },
                    onImportClicked: { onImportClicked?() }
                )
            }
        }
        .overlay(alignment: .bottomTrailing) {
            Button(action: onNewInstrumentClicked) {
                Image(systemName: "plus")
                    .font(.title.weight(.semibold))
                    .padding()
                    .background(Color.accentColor)
                    .foregroundStyle(.white)
                    .clipShape(Circle())
                    .shadow(radius: 4, x: 0, y: 4)
            }
            .padding()
        }
    }
}
