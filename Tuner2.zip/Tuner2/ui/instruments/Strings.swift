import SwiftUI

/// Displays all strings of an instrument.
/// Equivalent to `Strings.kt`.
struct Strings: View {
    
    let strings: [MusicalNote]
    let selectedNote: MusicalNote?
    var onStringClicked: (Int, MusicalNote) -> Void // index, note
    
    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                ForEach(Array(strings.enumerated()), id: \.offset) { index, note in
                    SingleString(
                        note: note,
                        isSelected: selectedNote?.match(note, ignoreOctave: false) ?? false,
                        onClick: { onStringClicked(index, note) }
                    )
                }
            }
            .padding()
        }
    }
}
