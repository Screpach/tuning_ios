import SwiftUI

/// Editor screen for instrument details and strings.
/// Equivalent to `InstrumentEditor.kt`.
struct InstrumentEditorPortrait: View {
    
    @ObservedObject var viewModel: InstrumentEditorViewModel
    var onIconButtonClicked: () -> Void
    var onNavigateUpClicked: () -> Void
    var onSaveNewInstrumentClicked: () -> Void
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Button(action: onIconButtonClicked) {
                    viewModel.icon.image
                        .resizable()
                        .renderingMode(.template)
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 48, height: 48)
                        .padding(8)
                        .background(MaterialTheme.colorScheme.surface)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                }
                
                TextField(String(localized: "instrument_name", defaultValue: "Instrument Name"), text: $viewModel.name)
                    .textFieldStyle(.roundedBorder)
                    .padding()
            }
            .padding()
            
            Divider()
            
            // Strings List
            List {
                Section(header: Text(String(localized: "strings", defaultValue: "Strings"))) {
                    ForEach(Array(viewModel.strings.enumerated()), id: \.offset) { index, note in
                        HStack {
                            Text(String(format: String(localized: "string_n", defaultValue: "String %d"), index + 1))
                            Spacer()
                            Text("\(note.base.rawValue)\(note.modifier.rawValue)\(note.octave)")
                                .bold()
                        }
                    }
                    .onDelete { indices in
                        viewModel.strings.remove(atOffsets: indices)
                    }
                    
                    Button(action: {
                        // Add default string
                        viewModel.strings.append(MusicalNote(.A, .None, 4))
                    }) {
                        Label(String(localized: "add_string", defaultValue: "Add String"), systemImage: "plus")
                    }
                }
                
                Section {
                    Toggle(String(localized: "chromatic", defaultValue: "Chromatic (No fixed strings)"), isOn: $viewModel.isChromatic)
                }
            }
            
            // Footer Actions
            HStack {
                Button(String(localized: "cancel", defaultValue: "Cancel"), role: .cancel, action: onNavigateUpClicked)
                Spacer()
                Button(String(localized: "save", defaultValue: "Save"), action: onSaveNewInstrumentClicked)
                    .buttonStyle(.borderedProminent)
            }
            .padding()
        }
        .navigationTitle(viewModel.name.isEmpty ? String(localized: "new_instrument", defaultValue: "New Instrument") : viewModel.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}
