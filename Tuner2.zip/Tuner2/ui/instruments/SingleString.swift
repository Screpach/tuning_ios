import SwiftUI

/// Visualizes a single instrument string with its note label.
/// Equivalent to `SingleString.kt`.
struct SingleString: View {
    
    let note: MusicalNote
    let isSelected: Bool
    var onClick: (() -> Void)?
    
    // Animation state
    @State private var xOffset: CGFloat = 0
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                // String Line
                Rectangle()
                    .fill(Color.secondary.opacity(0.5))
                    .frame(height: 2)
                    .offset(y: 0) // Center vertically handled by ZStack
                
                // Note Label (Animated)
                CustomLabel(
                    color: isSelected ? MaterialTheme.colorScheme.primary : MaterialTheme.colorScheme.surface,
                    onClick: onClick
                ) {
                    Text(formatNote(note))
                        .font(.caption)
                        .bold()
                        .foregroundStyle(isSelected ? .white : .primary)
                }
                // .offset(x: ...) // Animation logic for vibrating string would go here
            }
            .frame(height: 40) // Fixed height per string
        }
    }
    
    private func formatNote(_ n: MusicalNote) -> String {
        return "\(n.base.rawValue)\(n.modifier.rawValue)\(n.octave)"
    }
}
