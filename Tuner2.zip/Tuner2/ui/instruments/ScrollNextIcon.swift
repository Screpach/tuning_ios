import SwiftUI

/// Icon for scrolling to the next string.
/// Equivalent to `ScrollNextIcon.kt`.
struct ScrollNextIcon: View {
    var body: some View {
        ZStack {
            Image(systemName: "arrow.right") // Placeholder
                .imageScale(.small)
                .offset(y: -5)
            Image(systemName: "music.note.list")
                .imageScale(.large)
        }
    }
}
