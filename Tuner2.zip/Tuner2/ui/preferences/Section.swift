import SwiftUI

struct Section: View {
    let title: String
    var modifier: Modifier = Modifier() // Dummy for API compatibility
    
    // Internal struct to mimic Compose modifier usage if passed
    struct Modifier {}
    
    var body: some View {
        HStack {
            // Leading spacing to match ListItem default leading content slot
            Spacer()
                .frame(width: 24)
            
            Text(title)
                .font(.headline) // Material Theme titleMedium equivalent
                .foregroundColor(.blue) // Material Primary color
                .padding(.vertical, 12)
            
            Spacer()
        }
        .frame(minHeight: 48) // Standard list item height
    }
}

struct Section_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            Section(title: "My Section")
            Divider()
        }
    }
}
