import SwiftUI

struct SimplePreference: View {
    let name: String
    let iconName: String // SFSymbol name (mapped from drawable resource ID)
    let supporting: String?
    var action: () -> Void = {}
    
    // Initializer matching Kotlin signature closely (ignoring Modifier)
    init(
        name: String,
        iconName: String, // Changed from Int resource ID to String for Swift
        supporting: String? = nil,
        action: @escaping () -> Void = {}
    ) {
        self.name = name
        self.iconName = iconName
        self.supporting = supporting
        self.action = action
    }

    var body: some View {
        Button(action: action) {
            HStack(spacing: 16) {
                // Leading Icon
                Image(systemName: iconName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 24, height: 24)
                    .foregroundColor(.gray)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(name)
                        .font(.body)
                        .foregroundColor(.primary)
                    
                    if let supportingText = supporting {
                        Text(supportingText)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .contentShape(Rectangle())
        }
    }
}

struct SimplePreference_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            SimplePreference(name: "About", iconName: "info.circle", supporting: "Version 1.0")
            SimplePreference(name: "Reset", iconName: "arrow.counterclockwise")
        }
    }
}
