import SwiftUI

// MARK: - Models
enum NightMode: Int, CaseIterable {
    case auto = 0
    case on = 1
    case off = 2
}

struct Appearance {
    var mode: NightMode = .auto
    var blackNightEnabled: Bool = false
    var useSystemColorAccents: Bool = false
}

// MARK: - View
struct AppearanceDialog: View {
    @Binding var appearance: Appearance
    var onDismiss: () -> Void = {}
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.4).ignoresSafeArea()
                .onTapGesture { onDismiss() }
            
            VStack(spacing: 0) {
                // Header
                VStack(spacing: 16) {
                    Image(systemName: "paintpalette") // R.drawable.ic_appearance
                        .resizable()
                        .scaledToFit()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.secondary)
                    
                    Text("Appearance") // R.string.appearance
                        .font(.headline)
                }
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                ScrollView {
                    VStack(spacing: 0) {
                        // Night Mode Options
                        RadioButtonLine(
                            selected: appearance.mode == .auto,
                            text: "Follow system" // R.string.night_mode_auto
                        ) {
                            appearance.mode = .auto
                        }
                        
                        RadioButtonLine(
                            selected: appearance.mode == .off,
                            text: "Light theme" // R.string.night_mode_off
                        ) {
                            appearance.mode = .off
                        }
                        
                        RadioButtonLine(
                            selected: appearance.mode == .on,
                            text: "Dark theme" // R.string.night_mode_on
                        ) {
                            appearance.mode = .on
                        }
                        
                        Divider().padding(.vertical, 8)
                        
                        // Black Night Mode
                        CheckedButtonLine(
                            checked: appearance.blackNightEnabled,
                            text: "Black night mode" // R.string.black_night_mode
                        ) { isChecked in
                            appearance.blackNightEnabled = isChecked
                        }
                        
                        // System Colors (iOS generally doesn't support Material You style dynamic colors fully, keeping for logic parity)
                        CheckedButtonLine(
                            checked: appearance.useSystemColorAccents,
                            text: "Use system color accents" // R.string.system_color_accents
                        ) { isChecked in
                            appearance.useSystemColorAccents = isChecked
                        }
                    }
                }
                .frame(maxHeight: 400)
                
                // Footer
                HStack {
                    Spacer()
                    Button("Close") { // R.string.close
                        onDismiss()
                    }
                    .padding(24)
                }
            }
            .background(Color(UIColor.systemBackground))
            .cornerRadius(28)
            .padding(24)
            .shadow(radius: 10)
        }
    }
}

struct AppearanceDialog_Previews: PreviewProvider {
    static var previews: some View {
        AppearanceDialog(appearance: .constant(Appearance()))
    }
}
