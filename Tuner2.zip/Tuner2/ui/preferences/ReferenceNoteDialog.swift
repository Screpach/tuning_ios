import SwiftUI

// MARK: - Protocols & Stubs
protocol ReferenceNoteDialogFrequencyDetector {
    var detectedFrequency: Float? { get } // simplified FloatState
    func startFrequencyDetection()
    func stopFrequencyDetection()
}

// Mock Dependencies
struct MusicalScale2 {
    let referenceNote: MusicalNote
}
struct MusicalNote {
    let name: String
    let octave: Int
}

// MARK: - View
struct ReferenceNoteDialog: View {
    let state: MusicalScale2 // This would likely be a state holder in Swift
    let notePrintOptions: NotePrintOptions
    let frequencyDetector: ReferenceNoteDialogFrequencyDetector
    var onReferenceNoteChange: (Float) -> Void // Simplified callback
    var onDismiss: () -> Void = {}
    
    // Local State
    @State private var frequencyString: String = "440.0"
    @State private var isListening = false
    @State private var selectedNoteIndex: Int = 0 // Placeholder logic for note selection
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.4).ignoresSafeArea()
                .onTapGesture { onDismiss() }
            
            VStack(spacing: 0) {
                // Header
                VStack(spacing: 16) {
                    Image(systemName: "waveform") // R.drawable.ic_frequency
                        .resizable()
                        .scaledToFit()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.secondary)
                    
                    Text("Reference Note") // R.string.reference_note
                        .font(.headline)
                }
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                ScrollView {
                    VStack(spacing: 20) {
                        // Frequency Input
                        TextField("Frequency", text: $frequencyString)
                            .keyboardType(.decimalPad)
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.secondary, lineWidth: 1)
                            )
                            .overlay(
                                Text("Hz")
                                    .padding(.trailing)
                                    .foregroundColor(.secondary),
                                alignment: .trailing
                            )
                        
                        // Note Selector (Simplified as text for this conversion)
                        HStack {
                            Text("Note")
                            Spacer()
                            Button("A4") {
                                // Logic to change note (e.g. show picker)
                            }
                            .buttonStyle(.bordered)
                        }
                        
                        // Microphone Button
                        Button(action: {
                            isListening.toggle()
                            if isListening {
                                frequencyDetector.startFrequencyDetection()
                            } else {
                                frequencyDetector.stopFrequencyDetection()
                            }
                        }) {
                            HStack {
                                Image(systemName: isListening ? "mic.fill" : "mic")
                                Text(isListening ? "Listening..." : "Measure from Microphone")
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(isListening ? Color.red.opacity(0.1) : Color.blue.opacity(0.1))
                            .cornerRadius(8)
                        }
                        
                        // Set Default Button
                        Button("Reset to Default (A4 = 440Hz)") {
                            frequencyString = "440.0"
                            // selectedNoteIndex = ...
                        }
                        .font(.caption)
                    }
                    .padding(.horizontal, 24)
                }
                
                // Footer
                HStack {
                    Button("Cancel") {
                        onDismiss()
                    }
                    .padding()
                    
                    Spacer()
                    
                    Button("Apply") {
                        if let freq = Float(frequencyString) {
                            onReferenceNoteChange(freq)
                        }
                        onDismiss()
                    }
                    .padding()
                }
                .padding(8)
            }
            .background(Color(UIColor.systemBackground))
            .cornerRadius(28)
            .padding(24)
            .shadow(radius: 10)
        }
    }
}

// Mock detector for preview
class TestReferenceNoteDialogFrequencyDetector: ReferenceNoteDialogFrequencyDetector {
    var detectedFrequency: Float? = 443.0
    func startFrequencyDetection() {}
    func stopFrequencyDetection() {}
}

struct ReferenceNoteDialog_Previews: PreviewProvider {
    static var previews: some View {
        ReferenceNoteDialog(
            state: MusicalScale2(referenceNote: MusicalNote(name: "A", octave: 4)),
            notePrintOptions: NotePrintOptions(),
            frequencyDetector: TestReferenceNoteDialogFrequencyDetector(),
            onReferenceNoteChange: { _ in }
        )
    }
}
