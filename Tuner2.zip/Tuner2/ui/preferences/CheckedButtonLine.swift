import SwiftUI

struct CheckedButtonLine: View {
    let checked: Bool
    let text: String // Replaces stringRes for Swift simplicity
    var modifier: Modifier = Modifier() // Placeholder for Compose Modifier
    var onClick: (Bool) -> Void
    
    // Internal struct to support Modifier-like behavior if needed
    struct Modifier {}
    
    var body: some View {
        Button(action: {
            onClick(!checked)
        }) {
            HStack(spacing: 16) {
                // Checkbox simulation
                Image(systemName: checked ? "checkmark.square.fill" : "square")
                    .resizable()
                    .frame(width: 24, height: 24)
                    .foregroundColor(checked ? .blue : .gray)
                
                Text(text)
                    .font(.body)
                    .foregroundColor(.primary)
                
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12) // Height approx 56dp
            .contentShape(Rectangle())
        }
    }
}

struct CheckedButtonLine_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            CheckedButtonLine(checked: true, text: "Enabled Option", onClick: { _ in })
            CheckedButtonLine(checked: false, text: "Disabled Option", onClick: { _ in })
        }
    }
}
