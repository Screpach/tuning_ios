import SwiftUI

// MARK: - Models Stubs
enum NotationType: String, CaseIterable, Identifiable {
    case standard = "Standard"
    case solfege = "Solfege"
    case indian = "Indian"
    var id: String { self.rawValue }
    
    var description: String {
        switch self {
        case .standard: return "C, D, E, F, G, A, B"
        case .solfege: return "Do, Re, Mi, Fa, Sol, La, Si"
        case .indian: return "Sa, Re, Ga, Ma, Pa, Dha, Ni"
        }
    }
}

enum OctaveNotation: String, CaseIterable, Identifiable {
    case standard = "Standard"
    case scientific = "Scientific"
    case helmholtz = "Helmholtz"
    var id: String { self.rawValue }
    
    var description: String {
        switch self {
        case .standard: return "C4"
        case .scientific: return "C4 (ISO)"
        case .helmholtz: return "c'"
        }
    }
}

struct NotePrintOptions {
    var notationType: NotationType = .standard
    var octaveNotation: OctaveNotation = .standard
}

// MARK: - View
struct NotationDialog: View {
    @State var notePrintOptions: NotePrintOptions
    var onNotationChange: (NotationType, OctaveNotation) -> Void
    var onDismiss: () -> Void = {}
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.4).ignoresSafeArea()
                .onTapGesture { onDismiss() }
            
            VStack(spacing: 0) {
                // Header
                VStack(spacing: 16) {
                    Image(systemName: "music.note.list") // R.drawable.ic_music_note
                        .resizable()
                        .scaledToFit()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.secondary)
                    
                    Text("Notation") // R.string.notation
                        .font(.headline)
                }
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                VStack(alignment: .leading, spacing: 24) {
                    // Notation Type Picker
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Note names") // Label
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Menu {
                            ForEach(NotationType.allCases) { type in
                                Button(action: {
                                    notePrintOptions.notationType = type
                                    onNotationChange(type, notePrintOptions.octaveNotation)
                                }) {
                                    HStack {
                                        Text(type.rawValue)
                                        if notePrintOptions.notationType == type {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }
                            }
                        } label: {
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(notePrintOptions.notationType.rawValue)
                                        .foregroundColor(.primary)
                                    Text(notePrintOptions.notationType.description)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                                Image(systemName: "chevron.down")
                                    .foregroundColor(.secondary)
                            }
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(Color.secondary, lineWidth: 1)
                            )
                        }
                    }
                    
                    // Octave Notation Picker
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Octave notation") // Label
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Menu {
                            ForEach(OctaveNotation.allCases) { type in
                                Button(action: {
                                    notePrintOptions.octaveNotation = type
                                    onNotationChange(notePrintOptions.notationType, type)
                                }) {
                                    HStack {
                                        Text(type.rawValue)
                                        if notePrintOptions.octaveNotation == type {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }
                            }
                        } label: {
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(notePrintOptions.octaveNotation.rawValue)
                                        .foregroundColor(.primary)
                                    Text(notePrintOptions.octaveNotation.description)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                                Image(systemName: "chevron.down")
                                    .foregroundColor(.secondary)
                            }
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(Color.secondary, lineWidth: 1)
                            )
                        }
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
                
                // Footer
                HStack {
                    Spacer()
                    Button("Done") { // R.string.done/close
                        onDismiss()
                    }
                    .padding(24)
                }
            }
            .background(Color(UIColor.systemBackground))
            .cornerRadius(28)
            .padding(24)
            .shadow(radius: 10)
        }
    }
}

struct NotationDialog_Previews: PreviewProvider {
    static var previews: some View {
        NotationDialog(notePrintOptions: NotePrintOptions(), onNotationChange: { _, _ in })
    }
}
