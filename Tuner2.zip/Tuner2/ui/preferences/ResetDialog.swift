import SwiftUI

struct ResetDialog: View {
    var onReset: () -> Void
    var onDismiss: () -> Void = {}
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.4).ignoresSafeArea()
                .onTapGesture { onDismiss() }
            
            VStack(spacing: 0) {
                // Header
                VStack(spacing: 16) {
                    Image(systemName: "arrow.counterclockwise") // R.drawable.ic_reset
                        .resizable()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.secondary)
                    
                    Text("Reset all settings") // R.string.reset_all_settings
                        .font(.headline)
                }
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                // Content
                Text("Are you sure you want to reset all settings to their default values? This cannot be undone.") // R.string.reset_settings_prompt
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
                
                // Buttons
                HStack {
                    Spacer()
                    
                    Button("No") { // R.string.no
                        onDismiss()
                    }
                    .padding(24)
                    
                    Button("Yes") { // R.string.yes
                        onReset()
                        onDismiss()
                    }
                    .padding(24)
                    .foregroundColor(.red)
                }
            }
            .background(Color(UIColor.systemBackground))
            .cornerRadius(28)
            .padding(40)
            .shadow(radius: 10)
        }
    }
}

struct ResetDialog_Previews: PreviewProvider {
    static var previews: some View {
        ResetDialog(onReset: {})
    }
}
