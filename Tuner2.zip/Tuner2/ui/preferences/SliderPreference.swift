import SwiftUI

struct SliderPreference: View {
    let name: String
    let value: Float
    let valueRange: ClosedRange<Float>
    let steps: Int
    let onValueChange: (Float) -> Void
    let iconName: String // SFSymbol
    let supporting: String?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top, spacing: 16) {
                // Leading Icon
                Image(systemName: iconName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 24, height: 24)
                    .foregroundColor(.gray)
                    .padding(.top, 12)
                
                VStack(alignment: .leading, spacing: 4) {
                    // Headline
                    Text(name)
                        .font(.body)
                        .foregroundColor(.primary)
                        .padding(.top, 12)
                    
                    // Supporting Content + Slider
                    VStack(alignment: .leading) {
                        if let supportingText = supporting {
                            Text(supportingText)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        Slider(
                            value: Binding(
                                get: { value },
                                set: { onValueChange($0) }
                            ),
                            in: valueRange,
                            step: (valueRange.upperBound - valueRange.lowerBound) / Float(steps + 1)
                        )
                    }
                }
                
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 12)
        }
    }
}

struct SliderPreference_Previews: PreviewProvider {
    static var previews: some View {
        SliderPreference(
            name: "Sensitivity",
            value: 50,
            valueRange: 0...100,
            steps: 9,
            onValueChange: { _ in },
            iconName: "waveform.path.ecg",
            supporting: "Adjust the microphone sensitivity"
        )
    }
}
