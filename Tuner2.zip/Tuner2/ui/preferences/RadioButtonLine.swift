import SwiftUI

struct RadioButtonLine: View {
    let selected: Bool
    let text: String // Replaces stringRes
    var modifier: Modifier = Modifier()
    var onClick: () -> Void
    
    struct Modifier {}
    
    var body: some View {
        Button(action: onClick) {
            HStack(spacing: 16) {
                // Radio Button simulation
                Image(systemName: selected ? "largecircle.fill.circle" : "circle")
                    .resizable()
                    .frame(width: 24, height: 24)
                    .foregroundColor(selected ? .blue : .gray)
                
                Text(text)
                    .font(.body)
                    .foregroundColor(.primary)
                
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .contentShape(Rectangle())
        }
    }
}

struct RadioButtonLine_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            RadioButtonLine(selected: true, text: "Selected Option", onClick: {})
            RadioButtonLine(selected: false, text: "Unselected Option", onClick: {})
        }
    }
}
