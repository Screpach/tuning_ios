import SwiftUI

struct SwitchPreference: View {
    let name: String
    let checked: Bool
    let onCheckChange: (Bool) -> Void
    let iconName: String // SFSymbol
    let supporting: String?
    
    var body: some View {
        HStack(spacing: 16) {
            // Leading Icon
            Image(systemName: iconName)
                .resizable()
                .scaledToFit()
                .frame(width: 24, height: 24)
                .foregroundColor(.gray)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(name)
                    .font(.body)
                    .foregroundColor(.primary)
                
                if let supportingText = supporting {
                    Text(supportingText)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            Toggle("", isOn: Binding(
                get: { checked },
                set: { onCheckChange($0) }
            ))
            .labelsHidden()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }
}

struct SwitchPreference_Previews: PreviewProvider {
    static var previews: some View {
        SwitchPreference(
            name: "Display on lock screen",
            checked: true,
            onCheckChange: { _ in },
            iconName: "lock",
            supporting: "Keep screen on while tuning"
        )
    }
}
