import SwiftUI

// MARK: - Models
enum WindowingFunction: String, CaseIterable, Identifiable {
    case topHat = "Top Hat"
    case hamming = "Hamming"
    case hann = "Hann"
    
    var id: String { self.rawValue }
    
    // In a real app, this would map to string resources
    var description: String {
        return self.rawValue
    }
}

// MARK: - View
struct WindowingFunctionDialog: View {
    @State var windowingFunction: WindowingFunction
    var onWindowingFunctionChanged: (WindowingFunction) -> Void
    var onDismiss: () -> Void = {}
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.4).ignoresSafeArea()
                .onTapGesture { onDismiss() }
            
            VStack(spacing: 0) {
                // Header
                VStack(spacing: 16) {
                    Image(systemName: "waveform.path") // R.drawable.ic_window_function
                        .resizable()
                        .scaledToFit()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.secondary)
                    
                    Text("Windowing Function") // R.string.windowing_function
                        .font(.headline)
                }
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                // Content
                ScrollView {
                    VStack(spacing: 0) {
                        ForEach(WindowingFunction.allCases) { function in
                            RadioButtonLine(
                                selected: function == windowingFunction,
                                text: function.description,
                                onClick: {
                                    windowingFunction = function
                                }
                            )
                        }
                    }
                }
                .frame(maxHeight: 400)
                
                // Footer
                HStack {
                    Spacer()
                    
                    Button("Abort") { // R.string.abort
                        onDismiss()
                    }
                    .padding(24)
                    
                    Button("Done") { // R.string.done
                        onWindowingFunctionChanged(windowingFunction)
                        onDismiss()
                    }
                    .padding(24)
                }
            }
            .background(Color(UIColor.systemBackground))
            .cornerRadius(28)
            .padding(24)
            .shadow(radius: 10)
        }
    }
}

struct WindowingFunctionDialog_Previews: PreviewProvider {
    static var previews: some View {
        WindowingFunctionDialog(
            windowingFunction: .hann,
            onWindowingFunctionChanged: { _ in }
        )
    }
}
