import SwiftUI

struct AboutDialog: View {
    var onDismiss: () -> Void = {}
    
    // Mocking BuildConfig.VERSION_NAME
    let versionName = "1.0.0"
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.4).ignoresSafeArea()
                .onTapGesture { onDismiss() }
            
            VStack(spacing: 0) {
                // Header / Icon
                VStack(spacing: 8) {
                    Image(systemName: "info.circle") // R.drawable.ic_info
                        .resizable()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.secondary)
                    
                    Text("About") // R.string.about
                        .font(.headline)
                }
                .padding(.top, 24)
                .padding(.bottom, 16)
                
                // Content
                ScrollView {
                    Text("Tuner Version \(versionName)\n\nCreated by Michael Moessner.\n\nThis app is free software distributed under the GNU General Public License v3.") // R.string.about_message
                        .font(.body)
                        .padding(.horizontal, 24)
                }
                .frame(maxHeight: 300) // Limit height
                
                // Buttons
                HStack {
                    Spacer()
                    Button("Acknowledged") { // R.string.acknowledged
                        onDismiss()
                    }
                    .padding(24)
                }
            }
            .background(Color(UIColor.systemBackground))
            .cornerRadius(28) // Material 3 standard corner radius
            .padding(40)
            .shadow(radius: 10)
        }
    }
}

struct AboutDialog_Previews: PreviewProvider {
    static var previews: some View {
        AboutDialog()
    }
}
