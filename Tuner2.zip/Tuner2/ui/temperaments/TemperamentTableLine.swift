import SwiftUI

// MARK: - Table Line View
struct TemperamentTableLine: View {
    let index: Int
    let item: TemperamentValueState
    let onValueChange: (String) -> Void
    let onNoteNameClick: (Bool) -> Void
    
    // In Compose, validation errors were passed in. Here we assume simple state or calculation.
    var isError: Bool = false
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                // Note Name (Clickable to edit)
                Button(action: {
                    onNoteNameClick(false) // Standard
                }) {
                    Text(item.noteName)
                        .font(.body)
                        .frame(width: 60, alignment: .leading)
                        .foregroundColor(.primary)
                }
                
                // Cent / Ratio Input
                TextField("0.0", text: Binding(
                    get: { item.centOrRatio },
                    set: { onValueChange($0) }
                ))
                .keyboardType(.decimalPad) // Or numbersAndPunctuation
                .multilineTextAlignment(.trailing)
                .padding(.vertical, 12)
                .foregroundColor(isError ? .red : .primary)
                
                // Unit Label
                Text("cents") // Logic to switch between cents/ratio usually exists
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .frame(width: 40)
            }
            .padding(.horizontal)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            
            // Expanded Note Editor (if active)
            if item.noteEditorState != .off {
                VStack {
                    Text("Select Note")
                        .font(.caption)
                        .padding(.top, 8)
                    
                    // Placeholder for Note Selector Grid
                    // In a real app, this would be a grid of buttons for C, C#, D, etc.
                    HStack {
                        ForEach(["C", "D", "E", "F", "G", "A", "B"], id: \.self) { note in
                            Button(note) {
                                // Logic to change note
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                    .padding()
                }
                .background(Color(UIColor.tertiarySystemGroupedBackground))
            }
        }
    }
}

// MARK: - Preview
struct TemperamentTableLine_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            TemperamentTableLine(
                index: 0,
                item: TemperamentValueState(noteName: "C", centOrRatio: "0.0", noteEditorState: .off),
                onValueChange: { _ in },
                onNoteNameClick: { _ in }
            )
            TemperamentTableLine(
                index: 1,
                item: TemperamentValueState(noteName: "C#", centOrRatio: "100.0", noteEditorState: .standard),
                onValueChange: { _ in },
                onNoteNameClick: { _ in }
            )
        }
    }
}
