import SwiftUI

// MARK: - Mock Models & Data Interfaces
// In the actual app, these would come from the domain layer.
struct Temperament3: Identifiable, Equatable {
    let id = UUID()
    let name: String
    // Other properties...
}

protocol TemperamentsDialog2StateProtocol: ObservableObject {
    var listData: EditableListDataStub { get set }
    // Add other necessary methods/properties
    func proposeRootNote(temperament: Temperament3) -> String
}

// Stub for EditableListData structure used in Compose
struct EditableListDataStub {
    var editableItems: [Temperament3]
    var activeItem: Temperament3?
}

// MARK: - Main View
struct TemperamentsDialog2<State: TemperamentsDialog2StateProtocol>: View {
    @ObservedObject var state: State
    let onDismiss: () -> Void
    
    @State private var showPredefined = false
    @State private var showCustom = true
    
    var body: some View {
        NavigationView {
            ZStack(alignment: .bottomTrailing) {
                List {
                    // Predefined Section
                    Section(
                        header: HStack {
                            Text("Predefined temperaments") // R.string.predefined_temperaments
                            Spacer()
                            Image(systemName: showPredefined ? "chevron.up" : "chevron.down")
                        }
                        .contentShape(Rectangle())
                        .onTapGesture {
                            withAnimation { showPredefined.toggle() }
                        }
                    ) {
                        if showPredefined {
                            // Example items
                            Text("Equal Temperament (12-EDO)")
                            Text("Just Intonation")
                        }
                    }
                    
                    // Custom Section
                    Section(
                        header: HStack {
                            Text("Custom temperaments") // R.string.custom_temperaments
                            Spacer()
                            Image(systemName: showCustom ? "chevron.up" : "chevron.down")
                        }
                        .contentShape(Rectangle())
                        .onTapGesture {
                            withAnimation { showCustom.toggle() }
                        }
                    ) {
                        if showCustom {
                            ForEach(state.listData.editableItems) { item in
                                HStack {
                                    if state.listData.activeItem == item {
                                        Image(systemName: "checkmark")
                                            .foregroundColor(.blue)
                                    }
                                    Text(item.name)
                                    Spacer()
                                    // Edit/More buttons would go here
                                    Button(action: { /* Details */ }) {
                                        Image(systemName: "info.circle")
                                    }
                                }
                                .onTapGesture {
                                    // Select item logic
                                }
                            }
                            .onDelete { indexSet in
                                // Delete logic
                            }
                        }
                    }
                }
                .listStyle(.insetGrouped)
                
                // FAB
                Button(action: {
                    // Add new temperament logic
                }) {
                    Image(systemName: "plus")
                        .font(.title2)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue) // Material Primary
                        .clipShape(Circle())
                        .shadow(radius: 4)
                }
                .padding()
            }
            .navigationBarTitle("Temperaments", displayMode: .inline)
            .navigationBarItems(leading: Button(action: onDismiss) {
                Image(systemName: "arrow.left")
            })
        }
    }
}

// MARK: - Preview Logic
class MockTemperamentDialogState: TemperamentsDialog2StateProtocol {
    @Published var listData: EditableListDataStub
    
    init() {
        self.listData = EditableListDataStub(
            editableItems: [
                Temperament3(name: "My Custom 1"),
                Temperament3(name: "My Custom 2")
            ],
            activeItem: nil
        )
    }
    
    func proposeRootNote(temperament: Temperament3) -> String {
        return "C"
    }
}

struct TemperamentsDialog2_Previews: PreviewProvider {
    static var previews: some View {
        TemperamentsDialog2(state: MockTemperamentDialogState(), onDismiss: {})
    }
}
