import SwiftUI

// MARK: - Models
enum NoteEditorState {
    case off
    case standard
    case enharmonic
}

struct TemperamentValueState: Identifiable {
    let id = UUID()
    var noteName: String
    var centOrRatio: String
    var noteEditorState: NoteEditorState = .off
    // Logic for validation errors would go here
}

class TemperamentEditorState: ObservableObject {
    @Published var name: String = "New Temperament"
    @Published var rootNote: String = "C4"
    @Published var values: [TemperamentValueState] = []
    
    // Stub methods
    func setRootNote(_ note: String) { self.rootNote = note }
    func addNote() { /* Logic */ }
}

// MARK: - Editor View
struct TemperamentEditor: View {
    @ObservedObject var state: TemperamentEditorState
    let onBack: () -> Void
    
    var body: some View {
        VStack(spacing: 0) {
            // Header / App Bar
            HStack {
                Button(action: onBack) {
                    Image(systemName: "arrow.left")
                }
                Text("Edit Temperament")
                    .font(.headline)
                    .padding(.leading)
                Spacer()
            }
            .padding()
            .background(Color(UIColor.systemBackground))
            .shadow(radius: 1)
            
            ScrollView {
                VStack(spacing: 16) {
                    // Name Field
                    CardView {
                        TextField("Name", text: $state.name)
                            .padding()
                    }
                    
                    // Root Note Selector
                    CardView {
                        HStack {
                            Text("Root Note") // R.string.root_note
                            Spacer()
                            // Simplification: Text representing the note selector
                            Text(state.rootNote)
                                .fontWeight(.bold)
                                .padding(8)
                                .background(Color.secondary.opacity(0.1))
                                .cornerRadius(4)
                        }
                        .padding()
                    }
                    
                    // Notes Table
                    CardView {
                        VStack(spacing: 0) {
                            ForEach(Array(state.values.enumerated()), id: \.element.id) { index, item in
                                TemperamentTableLine(
                                    index: index,
                                    item: item,
                                    onValueChange: { newVal in
                                        state.values[index].centOrRatio = newVal
                                    },
                                    onNoteNameClick: { enharmonic in
                                        // Handle editor toggle
                                    }
                                )
                                
                                if index < state.values.count - 1 {
                                    Divider()
                                }
                            }
                        }
                    }
                    
                    // Action Buttons (Add note, etc)
                    Button("Add Note") {
                        state.addNote()
                    }
                    .padding()
                }
                .padding()
            }
        }
        .background(Color(UIColor.systemGroupedBackground))
    }
}

// Helper Card View
struct CardView<Content: View>: View {
    let content: Content
    
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    
    var body: some View {
        content
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(12)
            .shadow(color: Color.black.opacity(0.05), radius: 2, x: 0, y: 1)
    }
}

// MARK: - Preview
struct TemperamentEditor_Previews: PreviewProvider {
    static var previews: some View {
        let state = TemperamentEditorState()
        state.values = [
            TemperamentValueState(noteName: "C", centOrRatio: "0.0"),
            TemperamentValueState(noteName: "C#", centOrRatio: "100.0"),
            TemperamentValueState(noteName: "D", centOrRatio: "200.0")
        ]
        return TemperamentEditor(state: state, onBack: {})
    }
}
