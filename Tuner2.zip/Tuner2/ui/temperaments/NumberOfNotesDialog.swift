import SwiftUI

// MARK: - Number Of Notes Dialog
struct NumberOfNotesDialog: View {
    let initialNumberOfNotes: Int
    let onDismissRequest: () -> Void
    let onDoneClicked: (Int) -> Void
    
    // Constants
    let minNumberOfNotes = 5
    let maxNumberOfNotes = 10000
    
    @State private var numberOfNotesString: String
    
    init(initialNumberOfNotes: Int, onDismissRequest: @escaping () -> Void, onDoneClicked: @escaping (Int) -> Void) {
        self.initialNumberOfNotes = initialNumberOfNotes
        self.onDismissRequest = onDismissRequest
        self.onDoneClicked = onDoneClicked
        self._numberOfNotesString = State(initialValue: String(initialNumberOfNotes))
    }
    
    var value: Int? {
        return Int(numberOfNotesString)
    }
    
    var hasErrors: Bool {
        guard let val = value else { return true }
        return val < minNumberOfNotes || val > maxNumberOfNotes
    }
    
    var maxValueExceeded: Bool {
        guard let val = value else { return false }
        return val > maxNumberOfNotes
    }
    
    var body: some View {
        // In SwiftUI, we often use a ZStack with a background blur for custom dialogs,
        // or standard .alert/.sheet. Here we mimic the Compose AlertDialog content.
        ZStack {
            Color.black.opacity(0.4).ignoresSafeArea()
                .onTapGesture {
                    onDismissRequest()
                }
            
            VStack(spacing: 0) {
                Text("Number of notes") // R.string.note_number
                    .font(.headline)
                    .padding()
                
                VStack(alignment: .leading) {
                    TextField("12", text: $numberOfNotesString)
                        .keyboardType(.numberPad)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(hasErrors ? Color.red : Color.gray, lineWidth: 1)
                        )
                        .overlay(
                            HStack {
                                Spacer()
                                if !numberOfNotesString.isEmpty {
                                    Button(action: { numberOfNotesString = "" }) {
                                        Image(systemName: "xmark.circle.fill")
                                            .foregroundColor(.gray)
                                    }
                                    .padding(.trailing, 8)
                                }
                            }
                        )
                    
                    if maxValueExceeded {
                        Text("Maximum value exceeded: \(maxNumberOfNotes)") // R.string.maximum_value_exceeded
                            .font(.caption)
                            .foregroundColor(.red)
                            .padding(.leading)
                    }
                }
                .padding()
                
                HStack {
                    Spacer()
                    Button("Cancel") { // R.string.cancel
                        onDismissRequest()
                    }
                    .padding(.horizontal)
                    
                    Button("OK") { // R.string.ok
                        if !hasErrors, let val = value {
                            onDoneClicked(val)
                        }
                    }
                    .disabled(hasErrors)
                    .padding(.horizontal)
                }
                .padding()
            }
            .background(Color(UIColor.systemBackground))
            .cornerRadius(28)
            .padding(40)
            .shadow(radius: 10)
        }
    }
}

// MARK: - Preview
struct NumberOfNotesDialog_Previews: PreviewProvider {
    static var previews: some View {
        NumberOfNotesDialog(
            initialNumberOfNotes: 12,
            onDismissRequest: {},
            onDoneClicked: { _ in }
        )
    }
}
