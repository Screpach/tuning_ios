import SwiftUI

// MARK: - Stubs for dependencies not in context
// These mimic the Domain/State objects expected by the original Kotlin code.
struct MusicalNoteStub: Identifiable, Equatable, Hashable {
    let id = UUID()
    let name: String
    let octave: Int
    
    var fullName: String { "\(name)\(octave)" }
}

struct InstrumentStub: Identifiable {
    let id = UUID()
    let name: String
    let iconName: String // SFSymbol
    let strings: [MusicalNoteStub]
}

protocol InstrumentTunerDataProtocol: ObservableObject {
    var instrument: InstrumentStub { get }
    var selectedNoteKey: Int? { get set }
    var pitchHistoryState: PitchHistoryState { get }
    var tuningState: TuningState { get }
    var targetNote: MusicalNoteStub { get }
    var targetNoteForLockButton: MusicalNoteStub { get }
    
    func onClearFixedTargetClicked()
    func selectNote(key: Int, note: MusicalNoteStub)
}

// MARK: - Main Instrument Tuner Screen
struct InstrumentTuner: View {
    @ObservedObject var data: InstrumentTunerDataState
    
    // Environment
    @Environment(\.verticalSizeClass) var verticalSizeClass
    
    var body: some View {
        GeometryReader { geometry in
            let isLandscape = geometry.size.width > geometry.size.height
            
            if isLandscape {
                InstrumentTunerLandscape(data: data)
            } else {
                InstrumentTunerPortrait(data: data)
            }
        }
    }
}

// MARK: - Portrait Layout
struct InstrumentTunerPortrait<Data: InstrumentTunerDataProtocol>: View {
    @ObservedObject var data: Data
    
    var body: some View {
        VStack(spacing: 0) {
            // Top Bar / Header
            ZStack {
                Text(data.instrument.name)
                    .font(.headline)
                
                HStack {
                    Spacer()
                    // Settings/Menu Button Placeholder
                    Button(action: {}) {
                        Image(systemName: "gearshape")
                            .padding()
                    }
                }
            }
            .padding(.top, 8)
            
            Spacer()
            
            // Note Display (Target Note)
            Text(data.targetNote.fullName)
                .font(.system(size: 80, weight: .bold, design: .rounded))
                .foregroundColor(colorForTuningState(data.tuningState))
            
            Spacer()
            
            // Pitch History Graph
            // Assuming PitchHistory view exists from previous conversion
            PitchHistory(
                state: data.pitchHistoryState,
                targetNoteName: data.targetNote.fullName,
                targetFrequency: 440.0, // Mock freq
                tuningState: data.tuningState
            )
            .frame(height: 200)
            .padding()
            
            Spacer()
            
            // String Selection / Instrument Strings
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 16) {
                    ForEach(Array(data.instrument.strings.enumerated()), id: \.offset) { index, note in
                        Button(action: {
                            if data.selectedNoteKey == index {
                                data.onClearFixedTargetClicked()
                            } else {
                                data.selectNote(key: index, note: note)
                            }
                        }) {
                            VStack {
                                Text(note.name)
                                    .fontWeight(.bold)
                                Text("\(note.octave)")
                                    .font(.caption)
                            }
                            .frame(width: 50, height: 80)
                            .background(
                                RoundedRectangle(cornerRadius: 25)
                                    .fill(data.selectedNoteKey == index ? Color.blue : Color.gray.opacity(0.2))
                            )
                            .foregroundColor(data.selectedNoteKey == index ? .white : .primary)
                        }
                    }
                }
                .padding()
            }
        }
    }
}

// MARK: - Landscape Layout
struct InstrumentTunerLandscape<Data: InstrumentTunerDataProtocol>: View {
    @ObservedObject var data: Data
    
    var body: some View {
        HStack(spacing: 0) {
            // Left Side: Strings & Controls
            VStack {
                Text(data.instrument.name)
                    .font(.headline)
                    .padding()
                
                ScrollView {
                    VStack(spacing: 12) {
                        ForEach(Array(data.instrument.strings.enumerated()), id: \.offset) { index, note in
                            Button(action: {
                                if data.selectedNoteKey == index {
                                    data.onClearFixedTargetClicked()
                                } else {
                                    data.selectNote(key: index, note: note)
                                }
                            }) {
                                HStack {
                                    Text(note.fullName)
                                    Spacer()
                                    if data.selectedNoteKey == index {
                                        Image(systemName: "lock.fill")
                                    }
                                }
                                .padding()
                                .background(
                                    RoundedRectangle(cornerRadius: 8)
                                        .fill(data.selectedNoteKey == index ? Color.blue : Color.gray.opacity(0.1))
                                )
                                .foregroundColor(data.selectedNoteKey == index ? .white : .primary)
                            }
                        }
                    }
                    .padding()
                }
            }
            .frame(width: 200)
            .background(Color(UIColor.secondarySystemBackground))
            
            Divider()
            
            // Right Side: Visualization
            VStack {
                Text(data.targetNote.fullName)
                    .font(.system(size: 60, weight: .bold))
                    .foregroundColor(colorForTuningState(data.tuningState))
                    .padding()
                
                PitchHistory(
                    state: data.pitchHistoryState,
                    targetNoteName: data.targetNote.fullName,
                    targetFrequency: 440.0,
                    tuningState: data.tuningState
                )
                .padding()
            }
        }
    }
}

// Helper
func colorForTuningState(_ state: TuningState) -> Color {
    switch state {
    case .inTune: return .green
    case .tooLow, .tooHigh: return .red
    case .unknown: return .gray
    }
}

// Mock Implementation for Preview
class InstrumentTunerDataState: InstrumentTunerDataProtocol {
    @Published var instrument = InstrumentStub(
        name: "Guitar (Standard)",
        iconName: "guitars",
        strings: [
            MusicalNoteStub(name: "E", octave: 2),
            MusicalNoteStub(name: "A", octave: 2),
            MusicalNoteStub(name: "D", octave: 3),
            MusicalNoteStub(name: "G", octave: 3),
            MusicalNoteStub(name: "B", octave: 3),
            MusicalNoteStub(name: "E", octave: 4)
        ]
    )
    @Published var selectedNoteKey: Int? = nil
    @Published var pitchHistoryState = PitchHistoryState(capacity: 20) // From previous file
    @Published var tuningState: TuningState = .inTune
    @Published var targetNote = MusicalNoteStub(name: "A", octave: 2)
    @Published var targetNoteForLockButton = MusicalNoteStub(name: "A", octave: 2)
    
    func onClearFixedTargetClicked() { selectedNoteKey = nil }
    func selectNote(key: Int, note: MusicalNoteStub) { selectedNoteKey = key; targetNote = note }
}

struct InstrumentTuner_Previews: PreviewProvider {
    static var previews: some View {
        InstrumentTuner(data: InstrumentTunerDataState())
    }
}
