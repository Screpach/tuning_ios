import SwiftUI

// MARK: - Preferences View
struct Preferences: View {
    // In a real app, this would use @AppStorage or a ViewModel
    @State private var displayOnLockScreen: Bool = false
    @State private var theme: Int = 0 // 0: Auto, 1: Light, 2: Dark
    
    // Actions
    var onResetClicked: () -> Void = {}
    var onAboutClicked: () -> Void = {}
    
    var body: some View {
        NavigationView {
            List {
                // Section: Input
                Section(header: Text("Input")) {
                    NavigationLink(destination: Text("Microphone Selection")) {
                        HStack {
                            Image(systemName: "mic")
                                .foregroundColor(.blue)
                            Text("Audio Source")
                        }
                    }
                }
                
                // Section: Appearance
                Section(header: Text("Appearance")) {
                    Picker(selection: $theme, label: Label("Theme", systemImage: "paintpalette")) {
                        Text("System Default").tag(0)
                        Text("Light").tag(1)
                        Text("Dark").tag(2)
                    }
                }
                
                // Section: Others
                Section(header: Text("Others")) {
                    Toggle(isOn: $displayOnLockScreen) {
                        Label("Display on lock screen", systemImage: "lock")
                    }
                    .tint(.blue)
                    
                    Button(action: onResetClicked) {
                        Label("Reset all settings", systemImage: "arrow.counterclockwise")
                            .foregroundColor(.primary)
                    }
                    
                    Button(action: onAboutClicked) {
                        Label("About", systemImage: "info.circle")
                            .foregroundColor(.primary)
                    }
                }
            }
            .navigationTitle("Settings")
        }
    }
}

// MARK: - Components (Mimicking Composables if needed elsewhere)
struct SimplePreference: View {
    let name: String
    let iconName: String // SFSymbol
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: iconName)
                    .foregroundColor(.gray)
                Text(name)
                    .foregroundColor(.primary)
                Spacer()
            }
        }
    }
}

struct SwitchPreference: View {
    let name: String
    let iconName: String
    @Binding var checked: Bool
    
    var body: some View {
        Toggle(isOn: $checked) {
            HStack {
                Image(systemName: iconName)
                    .foregroundColor(.gray)
                Text(name)
            }
        }
    }
}

struct Preferences_Previews: PreviewProvider {
    static var previews: some View {
        Preferences()
    }
}
