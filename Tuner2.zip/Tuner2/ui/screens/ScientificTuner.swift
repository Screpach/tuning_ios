import SwiftUI

// MARK: - Protocols & Stubs
protocol ScientificTunerDataProtocol: ObservableObject {
    var tuningState: TuningState { get }
    var currentFrequency: Float? { get }
    var targetNote: MusicalNoteStub { get }
    var pitchHistoryState: PitchHistoryState { get }
    // Add Plot Data references here if passing real data
}

class MockScientificData: ScientificTunerDataProtocol {
    @Published var tuningState: TuningState = .inTune
    @Published var currentFrequency: Float? = 440.0
    @Published var targetNote = MusicalNoteStub(name: "A", octave: 4)
    @Published var pitchHistoryState = PitchHistoryState(capacity: 50)
}

// MARK: - Scientific Tuner View
struct ScientificTuner: View {
    @ObservedObject var data: MockScientificData
    
    var body: some View {
        GeometryReader { geometry in
            let isLandscape = geometry.size.width > geometry.size.height
            
            if isLandscape {
                ScientificTunerLandscape(data: data)
            } else {
                ScientificTunerPortrait(data: data)
            }
        }
    }
}

// MARK: - Portrait
struct ScientificTunerPortrait: View {
    @ObservedObject var data: MockScientificData
    
    var body: some View {
        VStack(spacing: 8) {
            // Header Info
            HStack {
                VStack(alignment: .leading) {
                    Text("Target: \(data.targetNote.fullName)")
                        .font(.headline)
                    if let freq = data.currentFrequency {
                        Text(String(format: "%.1f Hz", freq))
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.blue)
                    } else {
                        Text("-- Hz")
                            .font(.title2)
                            .foregroundColor(.gray)
                    }
                }
                Spacer()
                // Status Indicator
                Circle()
                    .fill(colorForTuningState(data.tuningState))
                    .frame(width: 20, height: 20)
            }
            .padding()
            
            Divider()
            
            // 1. Spectrum / Frequency Plot
            // (Using the converted FrequencyPlot from previous context)
            ZStack {
                Color(UIColor.secondarySystemBackground)
                Text("Frequency Plot")
                    .foregroundColor(.secondary)
                // Real implementation: FrequencyPlot(...)
            }
            .frame(maxHeight: .infinity)
            .cornerRadius(12)
            .padding(.horizontal)
            
            // 2. Correlation Plot
            ZStack {
                Color(UIColor.secondarySystemBackground)
                Text("Correlation Plot")
                    .foregroundColor(.secondary)
                // Real implementation: CorrelationPlot(...)
            }
            .frame(height: 150)
            .cornerRadius(12)
            .padding(.horizontal)
            
            // 3. Pitch History
            PitchHistory(
                state: data.pitchHistoryState,
                targetNoteName: data.targetNote.fullName,
                targetFrequency: 440.0,
                tuningState: data.tuningState
            )
            .frame(height: 150)
            .padding()
        }
    }
}

// MARK: - Landscape
struct ScientificTunerLandscape: View {
    @ObservedObject var data: MockScientificData
    
    var body: some View {
        HStack(spacing: 8) {
            // Left Column: Plots
            VStack(spacing: 8) {
                ZStack {
                    Color(UIColor.secondarySystemBackground)
                    Text("Frequency Plot")
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .cornerRadius(8)
                
                ZStack {
                    Color(UIColor.secondarySystemBackground)
                    Text("Correlation Plot")
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .cornerRadius(8)
            }
            .padding(8)
            
            // Right Column: Stats & History
            VStack {
                Text(data.targetNote.fullName)
                    .font(.largeTitle)
                    .bold()
                
                Text(String(format: "%.1f Hz", data.currentFrequency ?? 0))
                    .font(.title)
                    .foregroundColor(.blue)
                
                PitchHistory(
                    state: data.pitchHistoryState,
                    targetNoteName: data.targetNote.fullName,
                    targetFrequency: 440.0,
                    tuningState: data.tuningState
                )
                .frame(height: 200)
            }
            .frame(width: 250)
            .padding()
            .background(Color(UIColor.systemBackground))
        }
    }
}

struct ScientificTuner_Previews: PreviewProvider {
    static var previews: some View {
        ScientificTuner(data: MockScientificData())
    }
}
