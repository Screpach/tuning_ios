import SwiftUI

// MARK: - View
struct StretchTuningOverview: View {
    // Data Sources
    // In a real app, these are @Published properties from a ViewModel
    @State private var predefinedTunings: [StretchTuning] = [
        StretchTuning(name: "Piano (Standard)", description: "Default", unstretchedFrequencies: [], stretchInCents: [])
    ]
    @State private var customTunings: [StretchTuning] = [
        StretchTuning(name: "My Custom 1", description: "Test", unstretchedFrequencies: [], stretchInCents: [])
    ]
    
    @State private var isPredefinedExpanded = false
    @State private var isCustomExpanded = true
    
    // Navigation
    @State private var editingTuning: StretchTuning? = nil
    
    var body: some View {
        NavigationView {
            ZStack(alignment: .bottomTrailing) {
                List {
                    // Predefined Section
                    Section(
                        header: DisclosureGroup("Predefined Tunings", isExpanded: $isPredefinedExpanded) {
                            if isPredefinedExpanded {
                                ForEach(predefinedTunings) { tuning in
                                    NavigationLink(destination: StretchTuningInfo(stretchTuning: tuning)) {
                                        Text(tuning.name)
                                    }
                                }
                            }
                        }
                    ) { EmptyView() } // Hack to hide default content if using custom header logic or just use DisclosureGroup row
                    
                    // Custom Section
                    Section(
                        header: DisclosureGroup("Custom Tunings", isExpanded: $isCustomExpanded) {
                            if isCustomExpanded {
                                ForEach(customTunings) { tuning in
                                    HStack {
                                        Text(tuning.name)
                                        Spacer()
                                        Button(action: { editingTuning = tuning }) {
                                            Image(systemName: "pencil")
                                                .foregroundColor(.blue)
                                        }
                                        .buttonStyle(BorderlessButtonStyle())
                                    }
                                }
                                .onDelete(perform: deleteCustomTuning)
                            }
                        }
                    ) { EmptyView() }
                }
                .listStyle(InsetGroupedListStyle())
                
                // FAB
                Button(action: {
                    let newTuning = StretchTuning(name: "New Tuning", description: "", unstretchedFrequencies: [], stretchInCents: [])
                    customTunings.append(newTuning)
                    editingTuning = newTuning
                }) {
                    Image(systemName: "plus")
                        .font(.title2)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .clipShape(Circle())
                        .shadow(radius: 4)
                }
                .padding()
            }
            .navigationTitle("Stretch Tunings")
            .sheet(item: $editingTuning) { tuning in
                StretchTuningEditor(state: StretchTuningEditorState(tuning: tuning))
            }
        }
    }
    
    func deleteCustomTuning(at offsets: IndexSet) {
        customTunings.remove(atOffsets: offsets)
    }
}

struct StretchTuningOverview_Previews: PreviewProvider {
    static var previews: some View {
        StretchTuningOverview()
    }
}
