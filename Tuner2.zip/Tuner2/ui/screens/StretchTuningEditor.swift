import SwiftUI

// MARK: - Model Stub
// Reusing/Assuming StretchTuning struct from ui/stretchtuning context
// If not available, we define a wrapper here.

class StretchTuningEditorState: ObservableObject {
    @Published var name: String = ""
    @Published var description: String = ""
    @Published var stretchTuning: StretchTuning // Assumes definition in StretchTuningInfo.swift
    @Published var selectedKey: Int? = nil
    
    init(tuning: StretchTuning) {
        self.stretchTuning = tuning
        self.name = tuning.name
        self.description = tuning.description
    }
    
    func addLine() {
        // Logic to add a default line
        stretchTuning.unstretchedFrequencies.append(100.0)
        stretchTuning.stretchInCents.append(0.0)
    }
    
    func removeLine(key: Int) {
        guard key < stretchTuning.unstretchedFrequencies.count else { return }
        stretchTuning.unstretchedFrequencies.remove(at: key)
        stretchTuning.stretchInCents.remove(at: key)
    }
    
    func modifyLine(freq: Double, stretch: Double, key: Int) {
        guard key < stretchTuning.unstretchedFrequencies.count else { return }
        stretchTuning.unstretchedFrequencies[key] = freq
        stretchTuning.stretchInCents[key] = stretch
    }
}

// MARK: - Editor View
struct StretchTuningEditor: View {
    @ObservedObject var state: StretchTuningEditorState
    @Environment(\.presentationMode) var presentationMode
    
    // State for Modify Dialog
    @State private var showModifyDialog = false
    @State private var modifyingKey: Int? = nil
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Button(action: { presentationMode.wrappedValue.dismiss() }) {
                    Image(systemName: "arrow.left")
                }
                Text("Edit Stretch Tuning")
                    .font(.headline)
                    .padding(.leading)
                Spacer()
                Button("Save") {
                    // Save logic
                    presentationMode.wrappedValue.dismiss()
                }
            }
            .padding()
            .background(Color(UIColor.systemBackground))
            .shadow(radius: 1)
            
            ScrollView {
                VStack(spacing: 20) {
                    // Metadata Inputs
                    VStack(alignment: .leading) {
                        Text("Name").font(.caption).foregroundColor(.secondary)
                        TextField("Enter name", text: $state.name)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        
                        Text("Description").font(.caption).foregroundColor(.secondary)
                        TextField("Enter description", text: $state.description)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                    .padding()
                    .background(Color(UIColor.secondarySystemBackground))
                    .cornerRadius(8)
                    
                    // Graph & Table Wrapper
                    // Reusing the Info/Table view logic from previous folder
                    StretchTuningInfo(stretchTuning: state.stretchTuning)
                        .frame(minHeight: 400)
                }
                .padding()
            }
        }
        .background(Color(UIColor.systemGroupedBackground))
        .navigationBarHidden(true)
    }
}

struct StretchTuningEditor_Previews: PreviewProvider {
    static var previews: some View {
        let tuning = StretchTuning(
            name: "My Piano",
            description: "Custom stretch",
            unstretchedFrequencies: [440],
            stretchInCents: [2]
        )
        StretchTuningEditor(state: StretchTuningEditorState(tuning: tuning))
    }
}
