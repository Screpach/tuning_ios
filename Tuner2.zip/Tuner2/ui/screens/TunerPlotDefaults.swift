import SwiftUI

// MARK: - Tuner Plot Style Definition
struct TunerPlotStyle {
    var tickFontStyle: Font
    var tickLineWidth: CGFloat
    var tickLineColor: Color
    var toleranceTickFontStyle: Font
    var toleranceColor: Color
    var plotPointSize: CGFloat
    var plotPointSizeInactive: CGFloat
    var plotLineWidth: CGFloat
    var plotLineWidthInactive: CGFloat
    var plotLineColor: Color
    var negativeColor: Color
    var positiveColor: Color
    var inactiveColor: Color
    var inactiveStringColor: Color
    var stringColor: Color
    var onNegativeColor: Color
    var onPositiveColor: Color
    var onInactiveColor: Color
    var onInactiveStringColor: Color
    var onStringColor: Color
    var targetNoteLineWith: CGFloat
    var extraMarkLineWidth: CGFloat
    var extraMarkLineColor: Color
    var extraMarkTextStyle: Font
    var plotHeadlineStyle: Font
    var stringFontStyle: Font
    var plotWindowOutline: PlotWindowOutline
    var plotWindowOutlineDuringGesture: PlotWindowOutline
    var noteSelectorStyle: Font
    var margin: CGFloat
    
    // Default Factory
    static func defaults() -> TunerPlotStyle {
        return TunerPlotStyle(
            tickFontStyle: .caption,
            tickLineWidth: 1.0,
            tickLineColor: .secondary,
            toleranceTickFontStyle: .caption2,
            toleranceColor: .green.opacity(0.5),
            plotPointSize: 4.0,
            plotPointSizeInactive: 2.0,
            plotLineWidth: 2.0,
            plotLineWidthInactive: 1.0,
            plotLineColor: .primary,
            negativeColor: .red,
            positiveColor: .green,
            inactiveColor: .gray,
            inactiveStringColor: .gray.opacity(0.5),
            stringColor: .primary,
            onNegativeColor: .white,
            onPositiveColor: .white,
            onInactiveColor: .white,
            onInactiveStringColor: .white,
            onStringColor: .white,
            targetNoteLineWith: 2.0,
            extraMarkLineWidth: 1.0,
            extraMarkLineColor: .yellow,
            extraMarkTextStyle: .caption,
            plotHeadlineStyle: .headline,
            stringFontStyle: .body,
            plotWindowOutline: PlotWindowOutline(lineWidth: 1, cornerRadius: 8, color: .primary),
            plotWindowOutlineDuringGesture: PlotWindowOutline(lineWidth: 3, cornerRadius: 8, color: .blue),
            noteSelectorStyle: .title,
            margin: 12.0
        )
    }
}
